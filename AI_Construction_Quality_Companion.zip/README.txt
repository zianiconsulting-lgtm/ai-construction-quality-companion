AI for Construction Quality Managers: 10 Practical Workflows for ITPs, NCRs and Quality Records
Companion toolkit 1.0 (First edition, 2026). Mounir Ziani. Practical AI for Construction & QHSE, Book 2.

datasets/  Fictional teaching data (Harbour Lane and the practice scenario). Not real records or benchmarks.
prompts/   Production prompts copied automatically from the chapters. Each prompt's status line in the
           book states what testing, if any, it has had, for that prompt version only. Check every
           output against its source records.
spreadsheets/  The main preparation route. For each workflow: a method (*_method.md) with numbered steps
           and a worked table, and an .xlsx workbook (open this first) that rebuilds the same checked
           table without programming. Formula CSVs (LibreOffice syntax) are supplied as an alternative.
           Checked with LibreOffice 26.2 only; see each method's "Which file to open".
tools/     Optional: small deterministic Python scripts (Python 3, standard library only) that prepare the
           checked tables the chapters give to an AI tool: coverage checks, status tables, weekly
           tables, cut-off filters. Run "python3 tools/<name>.py --help" for the inputs.
           The scripts decide nothing: they grant no status, release nothing and close nothing.
           A person checks every table before it is used; each script's header says what to check.

All people, organisations, records, criteria and numbers are fictional.
manifest.csv  Every file in this folder with its size and SHA-256.

Permission to reuse the tools: you may copy and adapt the templates, checklists, spreadsheets and production
prompts in this toolkit for your own professional, training and organisational work, including commercial
project work. This permission does not allow resale or redistribution of the book or this toolkit, in whole or
in part, as a competing publication or template collection, and gives no rights in third-party material.
© 2026 Mounir Ziani.
