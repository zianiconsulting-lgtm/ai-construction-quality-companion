# Chapter 1: the coverage check by hand or in a spreadsheet

This is the main way to prepare the coverage check of Chapter 1: one result for every supplied clause, every activity-list line and every document the coverage matrix names. No programming is needed. The Python script `ch01_coverage_check.py` is an optional shortcut that applies the same rules. On the fictional Harbour Lane example and on a set of boundary cases (listed at the end), the spreadsheet results and the script results have been compared cell by cell and agree.

The rules are **author recommendations** (Chapter 1), applied to the **fictional project rules** QP-ITP-1 to QP-ITP-4. All clauses, documents and results are fictional.

## Which file to open

**Open the `.xlsx` workbook first.** Each workbook holds the Harbour Lane example rows on the left and the formula columns on the right, with the calculated values already stored:

- `ch01_coverage_check_formulas.xlsx` (alternative: `ch01_coverage_check_formulas.csv`)

- **The formula CSVs are an alternative** for readers who prefer plain text. Their formulas use the LibreOffice argument separator `;`. Spreadsheet applications that expect `,` may not read them as formulas, so in that case use the `.xlsx` file.
- **What was checked, and with what.** Each `.xlsx` was produced with LibreOffice 26.2 from its formula CSV. LibreOffice calculated every formula, and the stored values were compared cell by cell with the optional Python tool's output for the same example, including the date-boundary cases. The two agree.
- **What was not tested.** Microsoft Excel, Apple Numbers and Google Sheets were not tested, and neither was recalculation after editing, in any application.
- **When you replace the example rows with your own records,** make sure the workbook recalculates. Keep automatic calculation on, or use your application's recalculate command. Then check a few results by hand against the steps below before relying on the table.

## Files

| File | What it does |
|---|---|
| `ch01_coverage_check_formulas.csv` | The whole check, inputs on the left, formulas on the right |
| `ch01_coverage_check_method.md` | This method, with the worked example |

Open the CSV in LibreOffice Calc (formulas use `;` between arguments). Excel users: open the file in LibreOffice and save it as `.xlsx`, or type the formulas with `,`. Replace the input rows with your own and keep the formula columns. The sheet has room for 15 matrix rows, 15 clauses, 10 lines, 8 register rows and 8 named documents; for more, copy the formula rows down and extend the ranges.

**Inputs (left):** the coverage matrix (`row_id` to `checked_by`); the supplied clauses with their revisions; the activity-list lines, in order; the register extract (document, revision, status); and the specification's register ID (`SPEC`).
**Helpers (middle):** columns marked `M:` work on each matrix row, `R:` on the register, `U:` on each document named in a value source, `D:` on each document result.
**Results (right):** `kind`, `ref`, `result`, `detail`, `flag`. `flag` = yes marks the rows a person must act on.

## Before you start

1. Write `value_doc` for every matrix row that states a value (`yes` or `by reference`): the document and revision it comes from, separated by `; ` (for example `S-201 rev C; bar schedule`). Where the clause itself states the criterion, write `clause text (clause ID)`. A blank there is an error, never "fine".
2. Classify every supplied clause in the matrix as one of:
   - **mapped**: it is checked on a named line;
   - **overarching procedure**: it governs the whole ITP or every point of a kind (submittal review, witness notice, ITP acceptance). It still applies; it is not one line's criterion. Give the reason;
   - **not applicable**: it genuinely does not apply to this package. Give the reason.
   Never record a procedure as "not applicable": that reads as if it could be ignored.
3. Sort the matrix in activity-list order. The script lists the lines for a clause in that order; the spreadsheet follows the matrix order.

## Step 1: check each matrix row

4. For each row, note every problem below. A row with any problem is listed as an error and needs correcting by the person who mapped it.

   - The clause is not among the supplied clauses, or its revision differs from the clause list.
   - `mapping` is not mapped, overarching procedure or not applicable.
   - `states_acceptance` is not yes, no or by reference.
   - A mapped row whose line is not on the activity list.
   - An overarching-procedure or not-applicable row that names a line, or has no reason.
   - Mapped by or checked by is blank.
   - The same line and clause appear twice.
   - The row states a value (`yes` or `by reference`) but `value_doc` is blank.

   Rows with either of the first two problems are left out of steps 2 to 4. Rows with other problems still count, but the check cannot be complete until they are corrected.

## Step 2: one result per clause

5. For each supplied clause, in the clause list's order:
   - at least one usable mapped row on a listed line: **mapped**; detail: the lines;
   - otherwise an overarching-procedure row: **overarching procedure**; detail: the reason and the checker;
   - otherwise a not-applicable row: **not applicable**; detail: the reason and the checker;
   - otherwise: **UNMAPPED**, flag yes. Only the Package Engineer decides what to do: map it to a line, classify it, or ask a question.

## Step 3: one result per line

6. For each activity-list line, look at its mapped rows:
   - none: **no clause mapped (no acceptance reference)**, flag yes;
   - any row says yes: **value stated**;
   - otherwise any row says by reference: **value by reference**;
   - otherwise: **no value stated: Not provided - confirmation required**, flag yes.
   Detail: the clauses on the line, in matrix order.

## Step 4: one result per document

7. List the specification itself first (`SPEC rev B`, used by: clauses). Then list each document named in a `value_doc`, once, in the order it first appears. Leave out `clause text (...)`: the clause is not a separate document.
8. Split a name at ` rev ` into the document and the revision. Look it up in the register extract, in this order:
   - document not in the extract: **Not in the supplied extract (may exist; confirm)**;
   - a revision is named and that revision is not in the extract: the same, plus "(rev X not in the register extract)";
   - the register records it as not supplied: **Not provided - confirmation required (register: not supplied)**;
   - no revision named: exactly one current entry gives **current (rev X)**; otherwise **revision not identified - confirmation required**;
   - the named revision is current: **current**; superseded: **SUPERSEDED - do not use**; no status: **register status not stated - confirmation required**; any other status: **register status '...' - confirmation required**.
   Only "current" results have flag no. Detail: the lines that use it.

## Step 5: summary

9. Count the clauses by result, the lines, and the matrix-row problems. With no UNMAPPED clause and no problem, the check is **complete**. Otherwise it is **incomplete**, and an ITP drafted from it may go to the accepting role **for comment only**, clearly labelled. It is never presented as ready for acceptance or for site use.

## Worked example: Harbour Lane frame ITP (fictional)

Inputs: the 15 clauses (SPEC-QA-01.1, 01.2, 01.9 and SPEC-FRM-02.1 to 04.4, rev B), the 8 frame lines of `itp_items.csv`, the 13 rows of `ch01_coverage_matrix.csv` and the register `document_register.csv`.

**Step 1.** No row has a problem. CM-07 and CM-10 give `clause text (SPEC-FRM-03.5)` and `clause text (SPEC-FRM-04.3)` as their value source.

**Step 2: clauses**

| Clause | Result | Detail |
|---|---|---|
| SPEC-QA-01.1 | overarching procedure | Governs the whole ITP: its submission and acceptance |
| SPEC-QA-01.2 | overarching procedure | Notice procedure for every witness point |
| SPEC-QA-01.9 | overarching procedure | Review procedure for every submittal under the ITP |
| SPEC-FRM-02.1 | mapped | ITP-FRM02.1 |
| SPEC-FRM-02.2 | mapped | ITP-FRM03.3 |
| SPEC-FRM-03.1 | mapped | ITP-FRM03.1 |
| SPEC-FRM-03.2 | mapped | ITP-FRM03.2 |
| SPEC-FRM-03.3 | **UNMAPPED** (flag) | no line and no classification (procedure or not applicable) |
| SPEC-FRM-03.4 | mapped | ITP-FRM03.2 |
| SPEC-FRM-03.5 | mapped | ITP-FRM03.5 |
| SPEC-FRM-03.6 | mapped | ITP-FRM03.2 |
| SPEC-FRM-04.1 | mapped | ITP-FRM04.1 |
| SPEC-FRM-04.2 | mapped | ITP-FRM04.2 |
| SPEC-FRM-04.3 | mapped | ITP-FRM04.3 |
| SPEC-FRM-04.4 | **UNMAPPED** (flag) | no line and no classification (procedure or not applicable) |

(The three reasons are shortened here; each also names the checker, the QA/QC Engineer.)

**Step 3: lines**

| Line | Result | Clauses |
|---|---|---|
| ITP-FRM02.1 | **no value stated: Not provided - confirmation required** (flag) | SPEC-FRM-02.1 |
| ITP-FRM03.1 | value by reference | SPEC-FRM-03.1 |
| ITP-FRM03.2 | value stated | SPEC-FRM-03.2; 03.4; 03.6 |
| ITP-FRM03.3 | value by reference | SPEC-FRM-02.2 |
| ITP-FRM03.5 | value stated | SPEC-FRM-03.5 |
| ITP-FRM04.1 | value by reference | SPEC-FRM-04.1 |
| ITP-FRM04.2 | value by reference | SPEC-FRM-04.2 |
| ITP-FRM04.3 | value stated | SPEC-FRM-04.3 |

**Step 4: documents**

| Document | Result | Used by |
|---|---|---|
| SPEC rev B | current | clauses |
| S-201 rev C | current | ITP-FRM03.1; ITP-FRM03.2 |
| bar schedule | Not in the supplied extract (may exist; confirm) (flag) | ITP-FRM03.1 |
| edge formwork and cast-in drawings | Not in the supplied extract (may exist; confirm) (flag) | ITP-FRM03.3 |
| strength-class drawing | Not in the supplied extract (may exist; confirm) (flag) | ITP-FRM04.1 |
| TS-01 | Not provided - confirmation required (register: not supplied) (flag) | ITP-FRM04.2 |

**Step 5: summary.** Incomplete: 15 clauses: 10 mapped, 3 overarching procedures, 0 not applicable, 2 unmapped; 8 lines; 0 matrix errors. For comment only: not for acceptance or site use.

## Boundary cases cross-checked

A separate fictional set (8 clauses, 5 lines, 14 matrix rows, 8 register rows) exercises: a value source given as clause text, in either position; a value stated with a blank source; two value sources in one row; a clause on two lines; a duplicate row; an unknown clause; a revision mismatch; a line not on the activity list; mapping and value entries not allowed; an overarching procedure that names a line; a not-applicable row with no reason and no mapper; and every document wording (current, current with no revision, two current revisions, superseded, revision not in the extract, no status, not supplied, another status, not in the extract). The spreadsheet and the script give the same result in every cell.

## What a person must still check

The method, like the script, checks completeness, not correctness:

- that each mapping is right: a clause mapped to the wrong line passes this check;
- that the clause list really contains every clause of the supplied sections, at the current revision;
- each overarching-procedure or not-applicable reason, the "states a value" judgement and the value source on each row;
- what to do with an unmapped clause (a new line, a classification, or a question): that is the Package Engineer's decision, checked by the QA/QC Engineer, never the spreadsheet's, the script's or an AI tool's.
