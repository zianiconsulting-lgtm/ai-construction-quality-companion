# Chapter 2: the status table by hand or in a spreadsheet

This is the main way to prepare the Chapter 2 status table. You need no programming. Work through it by hand, or in any spreadsheet. The Python script `ch02_status_table.py` is optional. It gives the same table, and the book checks the two against each other on the Harbour Lane example and on the date cases below.

Harbour Lane and every record here are fictional teaching material. The rule SPEC-QA-01.9 ("Materials shall not be used before status A or B is recorded") is a **fictional project rule**. The ordering conventions below are an **author recommendation**: they are not taken from any standard.

The table prepares a review. It decides nothing. It grants no status, releases nothing and directs no containment.

## Which file to open

**Open the `.xlsx` workbook first.** Each workbook holds the Harbour Lane example rows on the left and the formula columns on the right, with the calculated values already stored:

- `ch02_status_table_formulas.xlsx` (alternative: `ch02_status_table_formulas.csv`)

- **The formula CSVs are an alternative** for readers who prefer plain text. Their formulas use the LibreOffice argument separator `;`. Spreadsheet applications that expect `,` may not read them as formulas, so in that case use the `.xlsx` file.
- **What was checked, and with what.** Each `.xlsx` was produced with LibreOffice 26.2 from its formula CSV. LibreOffice calculated every formula, and the stored values were compared cell by cell with the optional Python tool's output for the same example, including the date-boundary cases. The two agree.
- **What was not tested.** Microsoft Excel, Apple Numbers and Google Sheets were not tested, and neither was recalculation after editing, in any application.
- **When you replace the example rows with your own records,** make sure the workbook recalculates. Keep automatic calculation on, or use your application's recalculate command. Then check a few results by hand against the steps below before relying on the table.
- **Function note:** `ch02_status_table_formulas.xlsx` use MAXIFS. MAXIFS is not available in older spreadsheet versions (for example, Excel before 2019); in such a version, follow the manual steps below instead.

## The ready-made sheet

`ch02_status_table_formulas.csv` holds the Harbour Lane example, with its formulas.

- **LibreOffice Calc:** open the file as comma-separated, with "Evaluate formulas" ticked. The formulas use `;` between arguments, which LibreOffice accepts in every locale.
- **Excel:** open the file in LibreOffice and save it as `.xlsx`, or change `;` to `,` in the formulas.

**The cast rows** (rows 2 to 10) hold the inputs on the left: the delivery line, delivery note, cast, date received and the certificate entered on the line. Next is `clarification_id`. Fill it in only for step 7. The results follow: `certificate`, `certificate_review`, `fixed`, `status_basis`, `status_recorded`, `spec_qa_01_9`, `condition_detail` and `containment_recorded`. Working columns come after the results. They show each step of the calculation, so you can follow it.

**The input blocks** sit below the cast rows. Each block starts with a plain header row:

- parameters (cut-off and flags);
- the certificate log;
- the fixing log;
- the submittal register, one row for each status record;
- clarifications;
- inspection records;
- communication records;
- the submittal schedule;
- the submittal check.

**Date order.** Every date becomes a helper number: `order = week*10 + day number` (Mon=1 … Sun=7). Week 4, Tuesday is 42. A smaller order is an earlier day. Equal orders mean the same day.

## Steps

1. **Set the cut-off.** Enter the cut-off week and day (Harbour Lane: Week 4, Tuesday, order 42). The cut-off is inclusive. Leave out every record dated after it, including any status recorded after it. Say whether the certificate log and the inspection records are complete logs or extracts. Name the product submittal that covers every delivery line (SUB-FRM-001).
2. **Submittal completeness** (submittal check block, one row per revision). List the documents the schedule requires for that submittal. Mark each one included or not included, and write the count "n of N". Mark the latest revision submitted by the cut-off "Latest" and the others "History". Copy every recorded status, with its role, date and record ID. If none is recorded, write "Not recorded". Completeness is not acceptance.
3. **Certificates, one row per cast.** List the certificate log entries for the cast. Count a certificate marked as a duplicate only once, and show the link, for example "MC-0235 (MC-0236 duplicate of MC-0235, counted once)". If the cast has no entry, write "None recorded", but only from a complete log. From an extract, write "not in the supplied extract (may exist; confirm)", together with what the delivery line shows.
4. **Fixing.** Find the cast in the fixing log and copy the location, fix ID and date. If it is not there, write "No fixing recorded". The *reference date* for the cast is then its fixing date, or the cut-off if no fixing is recorded.
5. **Status history.** In the register, find every revision of the product submitted on or before the reference date. Under each revision, list every status recorded by the cut-off with its record ID and date: "rev 0: B (RS-002, Week 1, Monday)". Never show only the latest. Tag a status "after fixing" if its order is greater than the fixing's. Tag it "same day as fixing, order not recorded" if the orders are equal. A revision with no status reads "Not recorded". In the sheet, the register rows for the product must be sorted by revision, then by status date. Give each revision one row for each status record.
6. **Rule result (SPEC-QA-01.9).** The *current revision* is the latest one submitted on or before the reference date. A status counts only if it was recorded **before the fixing**. With no fixing recorded, a status recorded on or before the cut-off day counts. Work through these checks in order:
   1. If no revision had been submitted, the result is **Not met**.
   2. If a new revision was submitted on the fixing day, nothing records whether it came before or after the fixing. The result is **Not determinable: same day, order unknown; confirm**.
   3. If any status for the current revision was recorded on the fixing day, nothing records which came first. The result is **Not determinable: same day, order unknown; confirm**, never "Met".
   4. Otherwise, take the latest status for the current revision recorded before the fixing. A or B gives **Met**, and C gives **Not met**. If two statuses fall on that same latest day, one A or B and one not, the result is **Not determinable — confirm**.
   5. If no status for the current revision was recorded before the fixing, a status recorded after the fixing does not count. *A later approval never establishes earlier permission.* Look at the latest earlier revision with a status recorded before the fixing. If that status is not A or B, or there is none, the result is **Not met**. If it is A or B, go to step 7.
7. **Earlier status A or B (ED-16).** An earlier revision's status is **neither carried forward nor cancelled** when a new revision is submitted. Look for an explicit project rule, or a recorded clarification, that covers all of these:
   - the earlier revision and the current one;
   - this cast or its delivery;
   - the date of use.

   It must also have been recorded **before** the fixing. If you find one, enter its record ID in `clarification_id` and the clarification block. The result then follows its stated effect: "status applies" gives **Met** and "status does not apply" gives **Not met**. Quote its record ID. If there is no such record, or it was recorded on or after the fixing day, the result is **Not determinable — confirm**.
8. **Certificate review record** (ITP-FRM03.5). List the review records that name the cast, or name its delivery note and no single cast of that delivery. If there is none, list the records that name only the location where the cast is fixed, and label each "names the location only". If there is still none, write "Not in the supplied extract (may exist; confirm)" for an extract, or "None recorded" for a complete log.
9. **Containment recorded.** List only the inspection records marked "Not accepted" and the communication records that name the cast, or its delivery note and no single cast of it. Label each communication record "(communication record)". Otherwise write "None recorded". Records that name only a location are found by hand.
10. **Counts.** Count the casts, the certificate records, the unique certificates, the casts with no certificate, and how many of those were fixed.
11. **Label and check.** Label the table "prepared by spreadsheet (or script), checked by [role]". Then do the checks below.

The sheet works to the day. If both the status and the fixing record a time, compare the times by hand for any same-day result. The Python script does this when both times are given: an earlier status time counts as before the fixing.

## Worked table: Harbour Lane, cut-off Week 4, Tuesday

**Submittal check**

| Submittal | Count | Not included | Status recorded |
|---|---|---|---|
| SUB-FRM-001 rev 0 (Latest) | 3 of 4 | SR-04 | B, Client's Engineer, Week 1, Monday (RS-002) |
| SUB-FRM-002 rev 0 (History) | 2 of 3 | SR-06 | C, Client's Engineer, Week 2, Wednesday (RS-005) |
| SUB-FRM-002 rev 1 (Latest) | 3 of 3 | None | Not recorded |

**One row per cast.** The status history for every cast is "rev 0: B (RS-002, Week 1, Monday)". B was recorded in Week 1, before every fixing, so every rule result is "Met".

| Cast | Certificate | Fixed | Rule result |
|---|---|---|---|
| C-4471 | MC-0228 | Bay C1 (FX-021; Week 3, Thursday) | Met |
| C-4472 | MC-0229 | Bay C1 (FX-022; Week 3, Thursday) | Met |
| C-4490 | MC-0231 | Bay D4 (FX-025; Week 4, Monday) | Met |
| C-4491 | MC-0232 | Bay D4 (FX-026; Week 4, Monday) | Met |
| C-4510 | None recorded | Bay D5 (FX-027; Week 4, Monday) | Met |
| C-4511 | None recorded | Bay D5 (FX-028; Week 4, Monday) | Met |
| C-4531 | MC-0235 (MC-0236 a duplicate, counted once) | No fixing recorded | Met |
| C-4532 | MC-0237 | No fixing recorded | Met |
| C-4533 | None recorded | No fixing recorded | Met |

**Certificate review and containment**

| Casts | Certificate review | Containment recorded |
|---|---|---|
| C-4471, C-4472 | INS-0092 (Accepted; names the location only) | None recorded |
| C-4490, C-4491 | Not in the supplied extract (may exist; confirm) | None recorded |
| C-4510, C-4511 | INS-0171 (Not accepted) | INS-0171 (inspection: Not accepted); CM-014 (communication record) |
| C-4531, C-4532 | Not in the supplied extract (may exist; confirm) | None recorded |
| C-4533 | Not in the supplied extract (may exist; confirm) | CM-014 (communication record) |

**Counts:** 9 casts; 7 certificate records, 6 unique; 3 casts with no certificate, 2 of them fixed.

"Met" is a reading of one rule from the recorded status. It is not a release or an acceptance, and it says nothing about certificates. The missing certificates for C-4510, C-4511 and C-4533 are a separate gap (SPEC-FRM-03.5).

## Worked date cases (change one input and compare)

| Change to the Harbour Lane inputs | Casts | Rule result |
|---|---|---|
| B (RS-002) recorded Week 3, Friday, instead of Week 1 | C-4471, C-4472 (fixed Week 3, Thursday) | Not met: B is tagged "after fixing" and does not count |
| The same | Casts fixed Week 4, Monday, and unfixed casts | Met |
| B recorded Week 3, Thursday, the day C1 was fixed, no times | C-4471, C-4472 | Not determinable: same day, order unknown; confirm |
| SUB-FRM-001 rev 1 submitted Week 3, Friday, status blank | Casts fixed Week 4, Monday, and unfixed casts | Not determinable — confirm (rev 0's B neither carried forward nor cancelled) |
| The same, with clarification CL-T1 (recorded Week 3, Friday, by the Client's Engineer: "status applies", rev 0 to rev 1, scope DN-0114) | C-4490, C-4491 | Met, citing CL-T1 |
| The same, with CL-T1 recorded Week 4, Tuesday | C-4490, C-4491 | Not determinable — confirm (CL-T1 not used: recorded after fixing) |

To try a case, change the input cells in the register or clarification blocks. In the clarification cases, also enter CL-T1 in `clarification_id` for C-4490 and C-4491. Each of these cases is cross-checked against the script by `tools/check_ch02.py`.

## What a person must still check

- The inputs are the right files, revisions and cut-off, and the extract flags are set correctly.
- One product submittal covers every delivery line.
- Each certificate is for that cast. The table matches IDs; it does not read certificates.
- Each certificate review record listed really reviewed that cast's certificates. Take most care with a record matched by location only, because a bay may hold bars from more than one delivery.
- Each fixing entry and each matched record really refers to that cast.
- Each record listed under containment really records a containment action. Records that name only a location are found by hand.
- Every date was read correctly. Every same-day case is either settled by recorded times or left "same day, order unknown".
- Every clarification used really covers that revision, material scope and date of use, and was recorded before the fixing.
- Every "Not determinable" result is put to the role that records statuses (at Harbour Lane, the Client's Engineer).
