# Chapter 4: the weekly tables by hand or in a spreadsheet

This is the main way to prepare the two checked tables of Chapter 4: Table A (weekly activity) and Table B (outstanding position at the cut-off, any week). No programming is needed. The Python script `ch04_weekly_tables.py` is an optional shortcut that applies the same rules; on the fictional Harbour Lane example and the date-boundary cases below, the spreadsheet results and the script results have been compared cell by cell and agree.

The rules are **author recommendations** (Chapter 4), applied here to the **fictional project rule** SPEC-QA-01.14: records are counted by event date, and only records entered by 12:00 on the Friday are included. All records and numbers are fictional.

## Which file to open

**Open the `.xlsx` workbook first.** Each workbook holds the Harbour Lane example rows on the left and the formula columns on the right, with the calculated values already stored:

- `ch04_weekly_activity_formulas.xlsx` (alternative: `ch04_weekly_activity_formulas.csv`)
- `ch04_weekly_boundary_formulas.xlsx` (alternative: `ch04_weekly_boundary_formulas.csv`)
- `ch04_weekly_holdpoints_formulas.xlsx` (alternative: `ch04_weekly_holdpoints_formulas.csv`)
- `ch04_weekly_ncrlog_formulas.xlsx` (alternative: `ch04_weekly_ncrlog_formulas.csv`)

- **The formula CSVs are an alternative** for readers who prefer plain text. Their formulas use the LibreOffice argument separator `;`. Spreadsheet applications that expect `,` may not read them as formulas, so in that case use the `.xlsx` file.
- **What was checked, and with what.** Each `.xlsx` was produced with LibreOffice 26.2 from its formula CSV. LibreOffice calculated every formula, and the stored values were compared cell by cell with the optional Python tool's output for the same example, including the date-boundary cases. The two agree.
- **What was not tested.** Microsoft Excel, Apple Numbers and Google Sheets were not tested, and neither was recalculation after editing, in any application.
- **When you replace the example rows with your own records,** make sure the workbook recalculates. Keep automatic calculation on, or use your application's recalculate command. Then check a few results by hand against the steps below before relying on the table.
- **Function note:** `ch04_weekly_ncrlog_formulas.xlsx` use MAXIFS. MAXIFS is not available in older spreadsheet versions (for example, Excel before 2019); in such a version, follow the manual steps below instead.

## Files

| File | What it does |
|---|---|
| `ch04_weekly_activity_formulas.csv` | Table A: one row per submission, its status, and the counts |
| `ch04_weekly_holdpoints_formulas.csv` | Table B, hold points: the position of every hold-point record |
| `ch04_weekly_ncrlog_formulas.csv` | Table B, NCRs: the latest event held at the cut-off, and the NCR counts |
| `ch04_weekly_boundary_formulas.csv` | Fourteen date-boundary cases, each with its own cut-off |

Open each CSV in LibreOffice Calc (formulas use `;` between arguments). Excel users: open the file in LibreOffice and save it as `.xlsx`, or type the formulas with `,`. Input columns are on the left, formula columns on the right. Replace the input rows with your own export; copy the formulas down.

## Ordering against the cut-off (all tables)

1. Give each day a number: Monday 1 to Sunday 7.
2. For a record, an entry or an event, work out `order = week*10 + day number`. Do the same for the cut-off (Week 10 Friday: 105).
3. Compare the orders:
   - lower than the cut-off: **before** (held at the cut-off);
   - higher: **after** (a later day of the same week counts as after, not only a later week);
   - equal (the cut-off day): compare the times, `HH:MM`. Time at or before the cut-off time: **before**; later: **after**. **No time: "timing uncertain: confirm"**. Never guess.

## Table A: weekly activity

4. Sort the submission log by entry time.
5. For each submission, look up its record's event week and day, result, point type and package in the register.
6. Give each submission one class, in this order:
   - event week not the week covered: **other week** (an earlier week is a late entry for that week);
   - entered after the cut-off (step 3 on the entry time): **late** (next report, as a late entry for this week);
   - the same record ID already counted above it: **duplicate** (keep it, link it, do not count it);
   - otherwise: **counted**.
7. Count: submissions; other week; late; held at the cut-off (submissions less other week less late); duplicates; unique records (counted). Give results, point types and packages as "n of N", where N is the unique records.
8. If two submissions of one record differ in any field, mark the result "Unresolved" and ask the person who made the record. The spreadsheet does not detect this; compare them by eye.

## Table B: hold points

9. List every hold-point record (ITP point type Hold) up to the week covered.
10. **In the register at the cut-off?** Use the record's event date (step 3). If the submission log has an entry for the record, use its **first** entry time instead: a record entered after the cut-off is not in the position, even if its event was in an earlier week.
11. **Release dates.** Note each release and its date:
    - on the record (*released by* filled): the date of its HPR record in the NCR log, else the date written in the remarks, else the record's own date;
    - in the NCR log: a "Hold point released" event of an NCR whose source inspection is this record.
12. Decide, in this order:
    - not in the register at the cut-off: **Not in the position** (after the cut-off, or entered after it);
    - a release on the record dated before the cut-off: **Released on the record**;
    - an NCR-log release dated before the cut-off: **Released later (NCR log)**; list it for the checker to confirm the link;
    - any date in steps 10 or 11 is "timing uncertain": **Timing uncertain: confirm**;
    - a release exists but is dated after the cut-off: **Open: no release recorded at the cut-off**;
    - otherwise: **Open: no release recorded**.

    Only the two "Open" results, and "Timing uncertain: confirm", go in Table B. A closed NCR is not a release.

## Table B: NCRs

13. Mark every NCR event before, after or uncertain (step 3).
14. For each NCR: if a "Closed" event is held at the cut-off, it is not in Table B. If any event is uncertain, mark the NCR "Timing uncertain: confirm". Otherwise its position is its **latest event held at the cut-off**: event, week, day, role and record ID.
15. Count NCRs issued and closed in the week covered (held events only), and the NCRs open at the cut-off.

## Worked table: Harbour Lane, Week 10, cut-off Friday 12:00

**Table A, exclusions**

| Submission | Record | Class | Why |
|---|---|---|---|
| RS-101 | INS-0366 | other week | Event Week 9 Thursday: late entry for Week 9 |
| RS-108 | INS-0416 | duplicate | Same record as RS-107 |
| RS-112 | INS-0419 | late | Entered Friday 15:30, after 12:00 |

The other nine submissions are **counted**. Counts: 12 submissions; 1 other week; 1 late; 10 held at the cut-off; 1 duplicate; **9 unique records**. Accepted 8 of 9; not accepted 1 of 9 (INS-0412). Hold 3, witness 3, surveillance 3 of 9. FRM 7, MEP 2, FIN 0 of 9.

**Table B, hold points (Weeks 1 to 10)**

| Record | In register | Release | Result |
|---|---|---|---|
| INS-0091, INS-0136, INS-0274 | before | on the record, undated: record date | Released on the record |
| INS-0306 (Week 7) | before | none | **Open: no release recorded** |
| INS-0396 (Week 9 Friday) | before | none | **Open: no release recorded** |
| INS-0408 (Monday) | entered Mon 11:40 | on the record, Week 10 Monday | Released on the record |
| INS-0412 (Tuesday) | entered Tue 11:05 | NCR-007 log, HPR-019, Thursday | Released later (NCR log) |
| INS-0431 (Thursday) | entered Thu 16:20 | on the record, HPR-019, Thursday | Released on the record |

**Table B, NCRs:** NCR-001 to NCR-004 closed (not in Table B). Open: NCR-005 (latest: correction reported complete, Week 10 Wednesday), NCR-006 (disposition recorded, Week 10 Monday, EI-015), NCR-007 (hold point released, Week 10 Thursday, HPR-019; no Closed event). Issued this week: 1 (NCR-007). Closed this week: 1 (NCR-004).

## Worked table: date-boundary cases (`ch04_weekly_boundary_formulas.csv`)

| Case | Situation | Result |
|---|---|---|
| BC-01 | Week 5 Friday record, cut-off Week 5 Monday 12:00 | Not in the position: after the cut-off |
| BC-03 / BC-04 | Friday record entered 10:00 / 15:00, cut-off Friday 12:00 | Open / Not in the position: entered after the cut-off |
| BC-05 | Week 4 record entered Week 5 Friday 16:00 | Not in the position: entered after the cut-off |
| BC-06 | Release on the record dated Week 6 Monday | Open: no release recorded at the cut-off |
| BC-08 / BC-09 | NCR-log release Friday 14:00 / 10:00 | Open at the cut-off / Released later (NCR log) |
| BC-11 / BC-12 | Friday record, or Friday release, with no time | Timing uncertain: confirm |

The file holds fourteen cases, including an earlier day of the same week (BC-02), a release before the cut-off (BC-07), a release in the next week (BC-10) and register times 09:30 and 13:00 (BC-13, BC-14).

## What a person must still check

The tables report records. They never accept, release or close anything.

- That the export is complete and current, and the cut-off and week are the ones the reporting rule states.
- That no hold point was released by a later record the method cannot link (a re-inspection with no NCR link, or a release recorded elsewhere), and that no release recorded here was withdrawn.
- That an undated release on a record was given by the cut-off.
- Every "Unresolved" record and every "timing uncertain: confirm" row, with the person who made the record.
- That an item listed as outstanding really is the same hold point or NCR, and that nothing outside these files (paper records, e-mails) changes the position. Then sign the tables as checked.
