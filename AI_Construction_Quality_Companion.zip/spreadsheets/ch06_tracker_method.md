# Chapter 6: corrective-action status tables by hand or in a spreadsheet

This is the main method for preparing the Chapter 6 status tables. It needs no programming. The Python script `ch06_tracker_tables.py` is optional: it applies the same rules and gives the same tables. Both were cross-checked, cell by cell, on the fictional Harbour Lane example and at the date-boundary cut-offs below.

All records, roles and numbers are fictional teaching material.

## Which file to open

**Open the `.xlsx` workbook first.** Each workbook holds the Harbour Lane example rows on the left and the formula columns on the right, with the calculated values already stored:

- `ch06_tracker_formulas.xlsx` (alternative: `ch06_tracker_formulas.csv`)

- **The formula CSVs are an alternative** for readers who prefer plain text. Their formulas use the LibreOffice argument separator `;`. Spreadsheet applications that expect `,` may not read them as formulas, so in that case use the `.xlsx` file.
- **What was checked, and with what.** Each `.xlsx` was produced with LibreOffice 26.2 from its formula CSV. LibreOffice calculated every formula, and the stored values were compared cell by cell with the optional Python tool's output for the same example, including the date-boundary cases. The two agree.
- **What was not tested.** Microsoft Excel, Apple Numbers and Google Sheets were not tested, and neither was recalculation after editing, in any application.
- **When you replace the example rows with your own records,** make sure the workbook recalculates. Keep automatic calculation on, or use your application's recalculate command. Then check a few results by hand against the steps below before relying on the table.
- **Function note:** `ch06_tracker_formulas.xlsx` use MAXIFS. MAXIFS is not available in older spreadsheet versions (for example, Excel before 2019); in such a version, follow the manual steps below instead.

## What you need

- the cut-off: a week and a day, meaning records to the end of that day;
- the role your project rules authorise to verify effectiveness (at Harbour Lane, the Client's Engineer, SPEC-QA-01.11 and SPEC-QA-01.18). If your rules name none, leave it blank: no action is then shown as verified;
- the corrective-action register: action ID, NCR, owner role, due week, reported-complete week, verified effective, verified by (role), verification record;
- the NCR log (NCR, week and day raised) and the NCR event log (NCR, week, day, event, role, record ID), in the order the events were recorded.

## The spreadsheet file

`ch06_tracker_formulas.csv` opens in LibreOffice Calc, which calculates the formulas (they use `;` between arguments). To use Excel, save the file from LibreOffice as `.xlsx` first. It holds:

- **Settings** (columns A and B): cut-off week, cut-off day number (Monday 1 to Friday 5), authorised verifier, and the cut-off order. Change only these three values to move the cut-off. Below them are the counts.
- **Event log**, then the **NCR log**, then the **register**: the input columns on the left of each block, and the working columns on their right. The result columns carry the same names as the script's output: `raised`, `latest_event`, `correction_verified`, `closed` for NCRs; `status`, `weeks_overdue`, `evidence`, `check_note` for actions.

To use your own records, paste them over the input columns and copy the formulas down to the last row. Extend every range in the formulas (for example `$E$2:$E$91`) to your last row.

## The method, step by step

Write every date as an **order number**: order = week × 10 + day number (Monday 1, Tuesday 2, Wednesday 3, Thursday 4, Friday 5). Week 14 Monday is 141; Week 13 Friday is 135. A record counts at the cut-off only if its order is less than or equal to the cut-off order.

**NCRs**

1. Keep each NCR raised on or before the cut-off. Leave the others out, and list them.
2. Keep each event on or before the cut-off. Ignore later events.
3. For each kept NCR, take the **last** kept event in the event log (the order recorded) as its latest event. Write it as: event, the record ID in brackets if it is a disposition, week and day, role.
4. Look for a kept "Correction verified" event and a kept "Closed" event. Write each as: week and day, role (or "role not recorded"), record ID (or "no record ID"). Write "Not recorded" or "Not closed" where there is none. A correction verification, a hold-point release or a re-inspection is not a closure.

**Actions**

5. Leave out any action whose NCR was raised after the cut-off, and list it.
6. **Reported-complete week after the cut-off week:** withhold it, and withhold the verification entry too. List both.
7. **Verification record with a date** ("Week N" and, if given, a day): if it is later than the cut-off, withhold the verification. If the result was "Yes" or "No" and the action was reported complete, the result becomes "Not yet verified". A record with only a week counts if that week is not later than the cut-off week.
8. Give each action one status, from its own row, in this order:
   - **Verified effective (recorded):** result "Yes", a record cited, and the verifying role is the authorised verifier;
   - **Verified not effective (recorded):** result "No" and a record cited;
   - **Reported complete - awaiting verification:** a reported-complete week, and no accepted verification;
   - **Overdue - not reported complete:** not reported, and the cut-off week is later than the action's own due week;
   - **Open - not yet due:** everything else.
9. **Weeks overdue** = cut-off week − due week, for overdue actions only; otherwise 0. An action due in the cut-off week is not overdue: its due week has not ended.
10. **Evidence:** "Reported complete Week N", then "Verification: result; role; record" where a verification entry remains. Write "None recorded" if there is neither.
11. **Check notes**, for a person to resolve:
    - reported complete in the cut-off week when the cut-off is Monday to Thursday: "reported in the cut-off week; day not recorded - confirm";
    - a verification record with no date: "verification record has no date - confirm it was recorded by the cut-off";
    - a "Yes" by a role other than the authorised verifier, or by no role: the action stays "awaiting verification", with a note naming both roles;
    - a verification result with no reported-complete week: "verification recorded but no reported-complete week - confirm".
12. Count the actions in each status, and the NCRs raised, closed and open.
13. Match every row by its ID, never by the wording of the action.

## Worked table: Harbour Lane, Week 14 Monday (end of day)

Cut-off order 141. Authorised verifier: Client's Engineer. Register: `ch06_ca_tracker_w14.csv`.

| Action | NCR | Due | Reported | Verification used | Status | Weeks overdue | Check note |
|---|---|---|---|---|---|---|---|
| CA-011 | NCR-007 | 12 | 12 | Not yet verified; no role; no record | Reported complete - awaiting verification | 0 | none |
| CA-012 | NCR-007 | 11 | 11 | Yes; Client's Engineer; Week 13 Friday audit AUD-04 (order 135, kept) | Verified effective (recorded) | 0 | none |
| CA-020 | NCR-001 | 6 | 6 | Yes; Client's Engineer; Audit AUD-01 | Verified effective (recorded) | 0 | record has no date - confirm |
| CA-022 | NCR-003 | 9 | 9 | Yes; Client's Engineer; Audit AUD-02 | Verified effective (recorded) | 0 | record has no date - confirm |
| CA-024 | NCR-005 | 12 | 12 | Yes; Client's Engineer; Audit AUD-03 | Verified effective (recorded) | 0 | record has no date - confirm |
| CA-028 | NCR-009 | 16 | blank | none | Open - not yet due | 0 | none |

Counts: 4 verified effective (recorded); 0 verified not effective; 1 reported complete, awaiting verification; 0 overdue; 1 open, not yet due; 6 actions.

NCRs at the cut-off: 11 raised (NCR-001 to NCR-011; NCR-012, raised Week 14 Wednesday, order 143, is left out). 8 closed, 3 open.

| NCR | Correction verified | Closed |
|---|---|---|
| NCR-001 | Week 5 Thursday, Client's Engineer, no record ID | Week 5 Thursday, Client's Engineer, NCR-001 |
| NCR-002 | Week 7 Tuesday, Client's Engineer, no record ID | Week 7 Tuesday, Client's Engineer, NCR-002 |
| NCR-003 | Week 8 Friday, Client's Engineer, no record ID | Week 8 Friday, Client's Engineer, NCR-003 |
| NCR-004 | Week 10 Wednesday, Client's Engineer, no record ID | Week 10 Wednesday, Client's Engineer, NCR-004 |
| NCR-005 | Week 11 Wednesday, Client's Engineer, no record ID | Week 11 Wednesday, Client's Engineer, NCR-005 |
| NCR-006 | Week 12 Friday, Client's Engineer, no record ID | Week 12 Friday, Client's Engineer, NCR-006 |
| NCR-007 | Week 10 Thursday, Client's Engineer, INS-0431 | Week 11 Monday, Client's Engineer, NCR-007 |
| NCR-008 | Week 14 Monday, Client's Engineer, no record ID | Week 14 Monday, Client's Engineer, NCR-008 |
| NCR-009 | Not recorded | Not closed |
| NCR-010 | Not recorded | Not closed |
| NCR-011 | Not recorded | Not closed |

Latest events of the open NCRs: NCR-009, disposition recorded (EI-018), Week 13 Friday, Client's Engineer; NCR-010, issued, Week 13 Tuesday, Project Quality Manager; NCR-011, disposition recorded (EI-020), Week 14 Monday, Client's Engineer. NCR-008 closed and NCR-011's disposition both fall on Week 14 Monday (order 141), so both count.

## Date-boundary cases

The same register extract run at other cut-offs, to test the due-week and record-date rules. At Weeks 16 and 17 this is a test of the rule only: the full register records CA-028 complete in Week 16.

| Cut-off | Action | Rule tested | Result |
|---|---|---|---|
| Week 16 Monday | CA-028, due Week 16, not reported | due week equal to the cut-off week | Open - not yet due; 0 weeks overdue |
| Week 17 Monday | CA-028, due Week 16, not reported | due week ended before the cut-off | Overdue - not reported complete; 1 week |
| Week 12 Monday | CA-011, reported Week 12 | reported in the cut-off week, day unknown | Reported complete - awaiting verification; note "reported in the cut-off week; day not recorded - confirm" |
| Week 11 Friday | CA-011, reported Week 12, due Week 12 | reported after the cut-off week | report withheld; Open - not yet due |
| Week 13 Friday | CA-012, AUD-04 dated Week 13 Friday | record exactly at the cut-off | Verified effective (recorded) |
| Week 13 Thursday | CA-012, AUD-04 dated Week 13 Friday | record one day after the cut-off | verification withheld; Reported complete - awaiting verification |

## What a person must still check

The method decides nothing. It does not verify, close or judge any action.

- that the register and the event log are complete and current, and that each row belongs to its NCR;
- every check note, including verification records with no date and reports in the cut-off week;
- that the authorised verifier is the role your contract and project rules name;
- the counts, against the register, before the tables go to anyone or into an AI tool.

Then label the tables "prepared by spreadsheet, checked by [role]", with the date.

## Limits of the spreadsheet version

- Text comparisons in a spreadsheet ignore capitals; the script does not. Keep role names spelt exactly as in the project rules.
- A verification record's date is read from the first "Week " in its text. Write dates as "Week 13 Friday" or "Week 13, Friday".
