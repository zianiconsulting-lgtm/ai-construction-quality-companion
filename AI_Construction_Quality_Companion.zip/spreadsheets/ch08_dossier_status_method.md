# Chapter 8: requirement status table, by hand or in a spreadsheet

This is the main way to prepare the Chapter 8 requirement status table. It needs no programming. The formula sheet `ch08_dossier_status_formulas.csv` does the same steps in LibreOffice Calc or Excel. The optional script `ch08_dossier_status.py` gives the same table. The method, the formula sheet and the script were cross-checked cell by cell on the fictional Harbour Lane example and on boundary cases: an entry received on the cut-off day and the day after, two candidates for one entry, type alone, an index extract and a status recorded by the wrong role.

All data are fictional. The rules below are the chapter's **author recommendation** for preparing counts before any AI drafting; your contract and project rules set the real requirements and roles.

## Which file to open

**Open the `.xlsx` workbook first.** Each workbook holds the Harbour Lane example rows on the left and the formula columns on the right, with the calculated values already stored:

- `ch08_dossier_status_formulas.xlsx` (alternative: `ch08_dossier_status_formulas.csv`)

- **The formula CSVs are an alternative** for readers who prefer plain text. Their formulas use the LibreOffice argument separator `;`. Spreadsheet applications that expect `,` may not read them as formulas, so in that case use the `.xlsx` file.
- **What was checked, and with what.** Each `.xlsx` was produced with LibreOffice 26.2 from its formula CSV. LibreOffice calculated every formula, and the stored values were compared cell by cell with the optional Python tool's output for the same example, including the date-boundary cases. The two agree.
- **What was not tested.** Microsoft Excel, Apple Numbers and Google Sheets were not tested, and neither was recalculation after editing, in any application.
- **When you replace the example rows with your own records,** make sure the workbook recalculates. Keep automatic calculation on, or use your application's recalculate command. Then check a few results by hand against the steps below before relying on the table.

## What you need

- The handover schedule: one line per requirement, with its document type, scope and the role that accepts it.
- The handover index at the cut-off: one line per entry, with the requirement it is filed against, the document title, the document type, the received week and day, the status, and the role that recorded the status.
- The cut-off, as a week and a day (here: Week 25, Monday).
- Whether the index is the full index or an extract.

## Steps

1. **Order every date.** For each index entry, write `order = week × 10 + day number` (Monday = 1 … Sunday = 7). Week 24, Wednesday is 243. The cut-off Week 25, Monday is 251. Leave the order blank when no received date is recorded.
2. **Set aside what is not current.** An entry with an order above the cut-off order is excluded: list it, and do not use it. An entry recorded as Superseded is listed separately and not counted. Everything else is current. An entry received on the cut-off day itself (order 251) is current.
3. **Match type to requirement.** For each current entry, look up the document type its requirement needs. If the entry's type is the same, the entry *counts for* that requirement. If it differs, the entry is *misfiled*: it counts for no requirement.
4. **Give each requirement exactly one "Counted as" value.** For each requirement, count the current entries that count for it.
   - **One entry:** copy its recorded status, with one exception. If the status is Accepted or Reviewed — comments open and it was recorded by a role other than the one the schedule gives for acceptance, write **Confirmation required**. If the status is anything other than Missing and there is no received date, also write **Confirmation required**.
   - **More than one entry:** **Confirmation required**.
   - **No entry, and the index is an extract:** **Not in the supplied extract (may exist; confirm)**.
   - **No entry, full index, and a possible match qualifies (step 5):** **Missing — possible match awaiting verification**.
   - **No entry, full index, no possible match:** **Missing**.
5. **Look for possible matches.** For each misfiled entry, a requirement is a *candidate* only if all three hold:
   - it needs the entry's document type;
   - it has no entry of its own (step 4);
   - at least one significant word of its scope appears in the entry's title.
   
   Significant words: write down the scope's words, in lower case and in the singular (boilers: boiler; finishes: finish; deliveries: delivery). Leave out words of one or two letters, numbers, the words of the document type itself (for a warranty: "warranty") and general words (all, and, the, for, with, from, includes, including, listed, rev, pack, set, file, copy, register, record, certificate, manual, drawing, document, level, system, section, photo). Type alone is never enough.
   
   If exactly one requirement is a candidate, write "possible match to confirm", with the matched words. If several are candidates, list them all and suggest none of them. A candidate is never counted against a requirement, and it changes no recorded status.
6. **Write the check note.** In this order, joined with "; ": any misfiled entry filed against the requirement ("HI-009 filed against it is type Warranty, not counted"); the reason for a Confirmation required or Missing value; the possible match, with its matched words.
7. **Total and reconcile.** Count the requirements in each "Counted as" value. Every requirement is in exactly one value, so the totals must add up to the number of requirements in the schedule. If they do not, stop and find the error.
8. **NCR states.** For each NCR linked to a current or superseded entry, take the last event recorded on or before the cut-off, and note whether "Correction verified" and "Closed" are recorded by then.
9. **Label and hand over for checking.** Head the table "Requirement status table: prepared by [method], checked by [role, date]", with the cut-off and "full index" or "extract". It becomes an input to drafting only once that role has checked it.

## Using the formula sheet

Open `ch08_dossier_status_formulas.csv` in LibreOffice Calc (comma-separated, UTF-8) or Excel. The input columns are on the left and the formula columns on the right; every header is plain text.

- **Columns A–B:** the cut-off week and day, whether the index is an extract (yes/no), the day-number table, and the totals by "Counted as", with the total and the number of requirements for step 7.
- **Columns D–N:** the handover index, as recorded. **O–U:** helper formulas for steps 1 to 3 (order, current, required type, counts for, misfiled).
- **Columns W–AA:** the handover schedule. **AB–AF:** up to five significant scope words per requirement (step 5), typed by you.
- **Columns AG onwards:** the result for each requirement: the entry used, its recorded fields, the candidate entry and the matched words, "counted as", the three parts of the check note, the check note and the suggested entry.

To use it for your own project, replace the input rows and extend the formula ranges to your number of rows. Formulas use only IF, AND, OR, COUNTIFS, COUNTA, SUM, INDEX, MATCH, VLOOKUP, ISNUMBER, SEARCH and MID, with `;` between arguments (LibreOffice syntax; Excel converts on opening an .xlsx copy).

Limits of the sheet, which a person handles by hand:

- It shows only the first misfiled entry of each type and the first misfiled entry filed against each requirement. If two misfiled entries share a type, work step 5 by hand.
- With more than one entry counting for a requirement, it writes "more than one: see index" instead of listing the entries.
- SEARCH finds a word inside a longer word ("heat" in "heating"). Type whole significant words.

## Worked table: Harbour Lane, cut-off Week 25, Monday, full index

Steps 1 and 2: every received entry has an order of 251 or less (the latest is HI-015, Week 24, Friday: 245), so nothing is excluded. HI-005 is Superseded (replaced by HI-006) and is not counted. HI-008 has no received date and is recorded as Missing.

Step 3: one current entry is misfiled. HI-009, "Boiler manufacturer's warranty certificate (listed as heating O&M on TR-MEP-14)", type Warranty, is filed against HR-08, which needs an O&M manual.

Step 5, for HI-009:

| Warranty requirement | Entry of its own? | Significant scope words | In the title? |
|---|---|---|---|
| HR-09, "Heating plant (boilers)" | none | heating, plant, boiler | heating, boiler |
| HR-15, "Drylining and finishes" | HI-015 | drylining, finish | not a candidate (has an entry) |

One candidate: HR-09. Possible match to confirm: HI-009 (matched words: heating, boiler). It is not counted against HR-09.

Steps 4 and 6:

| Requirement | Entry used | Counted as | Check note |
|---|---|---|---|
| HR-01 | HI-001 | Accepted | |
| HR-02 | HI-002 | Accepted | |
| HR-03 | HI-003 | Reviewed — comments open | |
| HR-04 | HI-004 | Received — not reviewed | |
| HR-05 | HI-006 | Accepted | |
| HR-06 | HI-007 | Reviewed — comments open | |
| HR-07 | HI-008 | Missing | recorded as Missing by Project Quality Manager |
| HR-08 | HI-009 (type Warranty) | Missing | HI-009 filed against it is type Warranty, not counted; no entry of the required type filed against it in the full index |
| HR-09 | none | Missing — possible match awaiting verification | no entry of the required type filed against it in the full index; possible match to confirm: HI-009 (matched words: heating, boiler; not counted) |
| HR-10 | HI-010 | Received — not reviewed | |
| HR-11 | HI-011 | Accepted | |
| HR-12 | HI-012 | Reviewed — comments open | |
| HR-13 | HI-013 | Received — not reviewed | |
| HR-14 | HI-014 | Accepted | |
| HR-15 | HI-015 | Received — not reviewed | |

Step 7:

| Counted as | Requirements |
|---|---|
| Accepted | 5 |
| Reviewed — comments open | 3 |
| Received — not reviewed | 4 |
| Missing | 2 |
| Missing — possible match awaiting verification | 1 |
| Not in the supplied extract (may exist; confirm) | 0 |
| Confirmation required | 0 |
| **Total** | **15** (the schedule has 15 requirements) |

Step 8: NCR-008 and NCR-011 have "Correction verified" and "Closed" recorded; NCR-016 is "Correction reported complete" (Week 18), with neither; NCR-018 has a disposition recorded; NCR-021, NCR-022 and NCR-023 are issued, with no disposition.

## Boundary cases (cross-checked)

| Case | Result |
|---|---|
| Entry received Week 25, Monday (order 251), cut-off 251 | Current: counted |
| Entry received Week 25, Tuesday (order 252) | Excluded: listed, not used |
| A second warranty requirement whose scope also has "boiler" | Both are candidates; none is suggested; both read "Missing — possible match awaiting verification" |
| HI-009's title has no word of HR-09's scope (type only) | No candidate; HR-09 reads "Missing" |
| Index is an extract without HI-010 and HI-013 | HR-08, HR-09, HR-10 and HR-13 read "Not in the supplied extract (may exist; confirm)"; HR-07 stays Missing (recorded) |
| HI-007 shown as Accepted by the Project Quality Manager | HR-06 reads "Confirmation required" |

## What a person must still check

The method applies fixed rules; it does not read documents. A named person must still check:

- that the index itself is right: received dates, statuses and the roles that recorded them;
- that each document is the right document for its requirement: content, scope, revision and signatures;
- every possible match and every misfiled entry with no candidate, against the document itself, before the index is changed. Matching words is not reading the document. Until the role that keeps the index changes it, the requirement keeps its "Counted as" value;
- every "Confirmation required" row, with the role that recorded the status;
- that the cut-off and the full-or-extract choice are right.
