# Chapter 9: filtering the records to a cut-off by hand or in a spreadsheet

This is the main method for preparing the Chapter 9 filter summary before any lessons are drafted. It needs no programming. The Python script `ch09_cutoff_filter.py` is optional: it applies the same rules and gives the same summary. Both were cross-checked, cell by cell, on the fictional Harbour Lane example and at the date-boundary cut-offs below.

All records, roles and numbers are fictional teaching material.

## Which file to open

**Open the `.xlsx` workbook first.** Each workbook holds the Harbour Lane example rows on the left and the formula columns on the right, with the calculated values already stored:

- `ch09_cutoff_formulas.xlsx` (alternative: `ch09_cutoff_formulas.csv`)

- **The formula CSVs are an alternative** for readers who prefer plain text. Their formulas use the LibreOffice argument separator `;`. Spreadsheet applications that expect `,` may not read them as formulas, so in that case use the `.xlsx` file.
- **What was checked, and with what.** Each `.xlsx` was produced with LibreOffice 26.2 from its formula CSV. LibreOffice calculated every formula, and the stored values were compared cell by cell with the optional Python tool's output for the same example, including the date-boundary cases. The two agree.
- **What was not tested.** Microsoft Excel, Apple Numbers and Google Sheets were not tested, and neither was recalculation after editing, in any application.
- **When you replace the example rows with your own records,** make sure the workbook recalculates. Keep automatic calculation on, or use your application's recalculate command. Then check a few results by hand against the steps below before relying on the table.
- **Function note:** `ch09_cutoff_formulas.xlsx` use MAXIFS. MAXIFS is not available in older spreadsheet versions (for example, Excel before 2019); in such a version, follow the manual steps below instead.

## What you need

- the cut-off: a week and a day, meaning records to the end of that day;
- the NCR log (NCR, week and day raised);
- the NCR event log (NCR, week, day, event, record ID);
- the corrective-action tracker (action, NCR, reported-complete week, verification record).

## The spreadsheet file

`ch09_cutoff_formulas.csv` opens in LibreOffice Calc, which calculates the formulas (they use `;` between arguments). To use Excel, save the file from LibreOffice as `.xlsx` first. It holds:

- **Settings** (columns A and B): cut-off week, cut-off day number (Monday 1 to Friday 5), and the cut-off order. Change only the first two values to move the cut-off.
- **Event log**, then the **NCR log**, then the **corrective actions**: the input columns on the left of each block, and the working columns on their right ("1" means yes). Each "so far" column builds its list down the rows; the last row holds the full list.
- **Summary** (the last three columns, `item`, `count`, `detail`): the same table as the script's `filter_summary.csv`.

To use your own records, paste them over the input columns, in ascending ID order, and copy the formulas down to the last row. Extend every range in the formulas (for example `$K$2:$K$25`) and every reference to a "so far" column's last row.

## The method, step by step

Write every date as an **order number**: order = week × 10 + day number (Monday 1, Tuesday 2, Wednesday 3, Thursday 4, Friday 5). Week 26 Monday is 261. A record counts at the cut-off only if its order is less than or equal to the cut-off order, so a record dated exactly at the cut-off is kept.

1. **NCRs.** Keep each NCR raised on or before the cut-off. Count and list those kept and those excluded.
2. **Events.** Keep each event on or before the cut-off. Count those kept and excluded.
3. **Corrective actions.** Keep each action whose NCR is kept; count and list the others as excluded.
4. **Withheld entries** (kept actions only):
   - a reported-complete week after the cut-off week: blank it, and its verification, and list it as "(reported complete Week N)";
   - a verification record dated "Week N" (with or without a day) later than the cut-off: blank it, and list it as "(verification dated after the cut-off)". If the action was reported complete, its result becomes "Not yet verified".
5. **Possible sources.** List the NCRs with a kept "Closed" event. Only these may be a source of lessons (SPEC-QA-01.17, fictional project rule). A "Correction verified" event alone is not closure.
6. **Open.** List the kept NCRs with no kept "Closed" event. They are not sources.
7. **Causes.** List each kept "Cause recorded" event as "NCR (record ID)". Every other NCR has no recorded cause.
8. **Undated records.** List each kept action whose verification record carries no "Week N" date, for a person to confirm.
9. **Write lists** as "first to last" when there are more than two IDs and they run without a gap (NCR-001 to NCR-014); otherwise separate them with commas. Write "none" for an empty list.

## Worked table: Harbour Lane, Week 26 Monday (end of day)

Cut-off order 261. Inputs: `ncrs.csv`, `ncr_events.csv`, `corrective_actions.csv`.

| Item | Count | Detail |
|---|---|---|
| NCRs kept (raised on or before the cut-off) | 24 | NCR-001 to NCR-024 |
| NCRs excluded (raised after the cut-off) | 0 | none |
| NCR events kept | 90 | |
| NCR events excluded (after the cut-off) | 0 | |
| Corrective actions kept | 13 | CA-011, CA-012, CA-020, CA-022, CA-024, CA-028, CA-030, CA-032, CA-034, CA-036, CA-038, CA-040, CA-042 |
| Corrective actions excluded (NCR raised after the cut-off) | 0 | none |
| Corrective-action entries withheld (dated after the cut-off) | 0 | none |
| NCRs with a Closed event at the cut-off (possible sources) | 14 | NCR-001 to NCR-014 |
| NCRs open at the cut-off (not sources) | 10 | NCR-015 to NCR-024 |
| Cause recorded events at the cut-off | 1 | NCR-007 (INV-007) |
| Verification records with no date (confirm) | 3 | CA-020, CA-022, CA-024 |

At Week 26 nothing is excluded, because every record is older than the cut-off. The boundary cases show the filter at work.

## Date-boundary cases

Each pair puts the same records exactly at the cut-off and then one day after it.

| Cut-off | Record | Position | Result |
|---|---|---|---|
| Week 13 Friday (135) | NCR-011, raised Week 13 Friday (135) | exactly at the cut-off | kept: 11 NCRs kept (NCR-001 to NCR-011), 13 excluded |
| Week 13 Thursday (134) | NCR-011, raised Week 13 Friday (135) | one day after | excluded: 10 kept (NCR-001 to NCR-010), 14 excluded (NCR-011 to NCR-024) |
| Week 13 Friday (135) | CA-012, AUD-04 dated Week 13 Friday | exactly at the cut-off | kept; withheld entries are CA-028 (reported complete Week 16) and CA-030 (reported complete Week 17) |
| Week 13 Thursday (134) | CA-012, AUD-04 dated Week 13 Friday | one day after | withheld: "CA-012 (verification dated after the cut-off)" |
| Week 11 Monday (111) | NCR-008, raised Week 11 Monday; NCR-007, "Closed" Week 11 Monday | exactly at the cut-off | both count: 8 NCRs kept (NCR-001 to NCR-008); possible sources NCR-001, NCR-002, NCR-003, NCR-004, NCR-007 |
| Week 10 Friday (105) | the same two records | one working day after | NCR-008 excluded (7 kept, NCR-001 to NCR-007); NCR-007 open, not a source; no cause recorded yet |
| Week 11 Friday (115) | CA-011 and CA-024, reported complete Week 12 | the following week | 3 withheld: "CA-011 (reported complete Week 12)", "CA-012 (verification dated after the cut-off)", "CA-024 (reported complete Week 12)" |

## What a person must still check

The method decides nothing. It does not close, verify or explain any NCR, and it does not judge whether an NCR is a good source of a lesson. "Closed" here means only that a "Closed" event is recorded.

- that the input files are complete and current, and that the cut-off is the one intended;
- every verification record with no date: was it recorded by the cut-off?
- a reported-complete week equal to the cut-off week (the day is not recorded);
- the counts, by hand, against the event log.

Then label the summary "prepared by spreadsheet, checked by [role]", with the date.

## Limits of the spreadsheet version

- The "first to last" form assumes the IDs are in ascending order and share one prefix, as in the book's files.
- A verification record's date is read from the first "Week " in its text. Write dates as "Week 13 Friday" or "Week 13, Friday".
