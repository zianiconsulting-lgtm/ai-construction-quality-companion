#!/usr/bin/env python3
"""Coverage check for an activity-to-clause coverage matrix (Chapter 1, ITP from specification extracts).

Python 3 standard library only. Deterministic: the same files always give the same report, row for row.

INPUTS (CSV files with these columns; the book's fictional files, or your own with the same columns)
  --clauses   specification clauses: clause_id, revision, text (other columns ignored)
  --scope     optional: which clauses were supplied, comma-separated; an entry ending in * is a prefix
              (e.g. "SPEC-FRM-*,SPEC-QA-01.1"). Default: every clause in --clauses.
  --lines     activity list: itp_item, activity, point_type (optional filter: --package, column 'package')
  --matrix    coverage matrix, built by a person, one row per (line, clause) or per not-applicable clause:
              row_id, itp_item, clause_id, revision, requires, states_acceptance (yes | no | by reference),
              value_doc (where the value is stated, separated by '; ', e.g. "S-201 rev C; bar schedule", or
              "clause text (SPEC-FRM-03.5)" when the clause itself states it; required when
              states_acceptance is yes or by reference),
              mapping (mapped | overarching procedure | not applicable), na_reason (the reason for an
              overarching-procedure or not-applicable row), mapped_by, checked_by
              An overarching procedure (e.g. a submittal review or witness-notice clause) governs the whole
              ITP, not one line: it still applies and is never "not applicable".
  --register  document register extract: doc_id, revision, status (current | superseded | not supplied)
  --spec-doc  optional: the register doc_id of the specification the clauses come from (e.g. SPEC)

OUTPUT (--out file.csv, or standard output): one row per finding, columns kind, ref, result, detail, flag
  kind=clause    every clause in scope: mapped (to which lines), overarching procedure (applies to the whole
                 ITP; reason; checker), not applicable (reason; checker) or UNMAPPED
  kind=line      every activity-list line: no clause mapped | value stated | value by reference |
                 no value stated: Not provided - confirmation required
  kind=document  every document the matrix names ("clause text (...)" is not a document), with the wording:
                 current | SUPERSEDED - do not use | Not provided - confirmation required (register: not
                 supplied) | Not in the supplied extract (may exist; confirm) | register status not stated -
                 confirmation required | revision not identified - confirmation required
  kind=error     a matrix row that cannot be checked (unknown clause or line, wrong revision, missing
                 reason, mapper or checker, duplicate row, value not allowed, a value stated with no source)
  kind=summary   complete | incomplete, with the counts. An ITP drafted while the check is incomplete may go
                 to the accepting role for comment only, labelled as such; never for acceptance or site use.
  flag=yes marks the rows a person must act on. Exit status 1 if any clause is unmapped or any error is found.

WHAT A PERSON MUST STILL CHECK (the script cannot)
  - that each mapping is right: a clause mapped to the wrong line passes this check;
  - that the clause file really contains every clause of the supplied sections, at the current revision;
  - each overarching-procedure or not-applicable reason, the "states_acceptance" judgement and the value
    source on each row;
  - what to do with an unmapped clause (a new line, a not-applicable record, or a question): that is the
    Package Engineer's decision, checked by the QA/QC Engineer, never the script's or an AI tool's.

Example (from the book folder):
  python3 05_Companion/public/tools/ch01_coverage_check.py --clauses 03_Datasets/spec_clauses.csv \
    --scope "SPEC-FRM-*,SPEC-QA-01.1,SPEC-QA-01.2,SPEC-QA-01.9" --lines 03_Datasets/itp_items.csv \
    --package FRM --matrix 03_Datasets/ch01_coverage_matrix.csv --register 03_Datasets/document_register.csv \
    --spec-doc SPEC --out coverage_check.csv
"""
import argparse
import csv
import io
import sys

ALLOWED_VALUE = ("yes", "no", "by reference")
ALLOWED_MAPPING = ("mapped", "overarching procedure", "not applicable")
REASONED = ("overarching procedure", "not applicable")  # rows with no line, and a reason
NOT_IN_EXTRACT = "Not in the supplied extract (may exist; confirm)"
NOT_PROVIDED = "Not provided - confirmation required"
FIELDS = ["kind", "ref", "result", "detail", "flag"]


def read(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def in_scope(cid, scope):
    if not scope:
        return True
    return any(cid.startswith(s[:-1]) if s.endswith("*") else cid == s for s in scope)


def doc_wording(token, register):
    """Wording for one document named in the matrix, from the register extract only."""
    ident, _, rev = token.partition(" rev ")
    ident, rev = ident.strip(), rev.strip()
    entries = [d for d in register if d["doc_id"] == ident]
    if not entries:
        return NOT_IN_EXTRACT, True
    if rev:
        entries = [d for d in entries if d.get("revision", "") == rev]
        if not entries:
            return NOT_IN_EXTRACT + f" (rev {rev} not in the register extract)", True
    statuses = [(d.get("status") or "").strip() for d in entries]
    if "not supplied" in statuses:
        return NOT_PROVIDED + " (register: not supplied)", True
    if not rev:
        cur = [d for d in entries if (d.get("status") or "").strip() == "current"]
        if len(cur) == 1:
            return f"current (rev {cur[0]['revision']})", False
        return "revision not identified - confirmation required", True
    status = statuses[0]
    if status == "current":
        return "current", False
    if status == "superseded":
        return "SUPERSEDED - do not use", True
    if not status:
        return "register status not stated - confirmation required", True
    return f"register status '{status}' - confirmation required", True


def check(clauses, lines, matrix, register, scope=None, spec_doc=None):
    """Return the report rows (list of dicts with FIELDS)."""
    out = []
    add = lambda kind, ref, result, detail="", flag=False: out.append(
        {"kind": kind, "ref": ref, "result": result, "detail": detail, "flag": "yes" if flag else "no"})
    clause = {c["clause_id"]: c for c in clauses if in_scope(c["clause_id"], scope)}
    items = [r["itp_item"] for r in lines]
    seen, errors = set(), 0

    # matrix rows that cannot be checked
    for r in matrix:
        rid, cid, it, m = r.get("row_id", "?"), r.get("clause_id", ""), r.get("itp_item", ""), r.get("mapping", "")
        problems = []
        if cid not in clause:
            problems.append(f"clause {cid or '[blank]'} is not in the supplied clauses")
        elif r.get("revision", "") != clause[cid].get("revision", ""):
            problems.append(f"revision {r.get('revision') or '[blank]'} differs from the clause file "
                            f"(rev {clause[cid].get('revision')})")
        if m not in ALLOWED_MAPPING:
            problems.append(f"mapping '{m}' not allowed")
        if r.get("states_acceptance", "") not in ALLOWED_VALUE:
            problems.append(f"states_acceptance '{r.get('states_acceptance', '')}' not allowed")
        if m == "mapped" and it not in items:
            problems.append(f"line {it or '[blank]'} is not on the activity list")
        if m in REASONED and it:
            problems.append(f"{m} row names a line")
        if m in REASONED and not (r.get("na_reason") or "").strip():
            problems.append(f"{m} without a reason")
        if r.get("states_acceptance", "") in ("yes", "by reference") and not (r.get("value_doc") or "").strip():
            problems.append("states a value with value_doc [blank]: name the document, or 'clause text (ID)'")
        if not (r.get("mapped_by") or "").strip():
            problems.append("mapped by: [blank]")
        if not (r.get("checked_by") or "").strip():
            problems.append("checked by: [blank]")
        key = (it, cid)
        if key in seen:
            problems.append("duplicate row for this line and clause")
        seen.add(key)
        for p in problems:
            add("error", rid, "cannot be checked", p, True)
            errors += 1
    good = [r for r in matrix if r.get("clause_id") in clause and r.get("mapping") in ALLOWED_MAPPING]

    # clauses
    counts = {"mapped": 0, "overarching procedure": 0, "not applicable": 0, "UNMAPPED": 0}
    for cid in clause:
        mapped = [r["itp_item"] for r in good if r["clause_id"] == cid and r["mapping"] == "mapped"
                  and r["itp_item"] in items]
        why = {m: [r for r in good if r["clause_id"] == cid and r["mapping"] == m] for m in REASONED}
        if mapped:
            counts["mapped"] += 1
            add("clause", cid, "mapped", "; ".join(sorted(set(mapped), key=items.index)))
        elif why["overarching procedure"] or why["not applicable"]:
            m = "overarching procedure" if why["overarching procedure"] else "not applicable"
            r0 = why[m][0]
            counts[m] += 1
            add("clause", cid, m, f"{r0['na_reason']} (checked by {r0.get('checked_by') or '[blank]'})")
        else:
            counts["UNMAPPED"] += 1
            add("clause", cid, "UNMAPPED", "no line and no classification (procedure or not applicable)", True)

    # lines
    for it in items:
        rows = [r for r in good if r["itp_item"] == it and r["mapping"] == "mapped"]
        cids = "; ".join(r["clause_id"] for r in rows)
        vals = {r["states_acceptance"] for r in rows}
        if not rows:
            add("line", it, "no clause mapped (no acceptance reference)", "", True)
        elif "yes" in vals:
            add("line", it, "value stated", cids)
        elif "by reference" in vals:
            add("line", it, "value by reference", cids)
        else:
            add("line", it, "no value stated: " + NOT_PROVIDED, cids, True)

    # documents: the specification itself, then each document the matrix names
    docs = {}
    if spec_doc:
        revs = sorted({c.get("revision", "") for c in clause.values()})
        for rev in revs:
            docs.setdefault(f"{spec_doc} rev {rev}" if rev else spec_doc, ["clauses"])
    for r in good:
        for tok in (r.get("value_doc") or "").split(";"):
            tok = tok.strip()
            if tok and not tok.lower().startswith("clause text"):  # the clause states it: not a document
                where = docs.setdefault(tok, [])
                if r["itp_item"] and r["itp_item"] not in where:
                    where.append(r["itp_item"])
    for tok, where in docs.items():
        wording, flag = doc_wording(tok, register)
        add("document", tok, wording, "used by: " + "; ".join(where), flag)

    complete = counts["UNMAPPED"] == 0 and errors == 0
    add("summary", "coverage", "complete" if complete else "incomplete",
        f"{len(clause)} clauses: {counts['mapped']} mapped, {counts['overarching procedure']} overarching "
        f"procedures, {counts['not applicable']} not applicable, {counts['UNMAPPED']} unmapped; {len(items)} lines; "
        f"{errors} matrix errors" + ("" if complete else ". For comment only: not for acceptance or site use"), True)
    return out


def to_csv(rows):
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=FIELDS, lineterminator="\n")
    w.writeheader()
    w.writerows(rows)
    return buf.getvalue()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--clauses", required=True)
    ap.add_argument("--scope", default="")
    ap.add_argument("--lines", required=True)
    ap.add_argument("--package", default="")
    ap.add_argument("--matrix", required=True)
    ap.add_argument("--register", required=True)
    ap.add_argument("--spec-doc", default="")
    ap.add_argument("--out", default="")
    a = ap.parse_args(argv)
    scope = [s.strip() for s in a.scope.split(",") if s.strip()]
    lines = [r for r in read(a.lines) if not a.package or r.get("package") == a.package]
    rows = check(read(a.clauses), lines, read(a.matrix), read(a.register), scope, a.spec_doc or None)
    text = to_csv(rows)
    if a.out:
        with open(a.out, "w", newline="", encoding="utf-8") as f:
            f.write(text)
    else:
        sys.stdout.write(text)
    bad = any(r["kind"] == "error" or r["result"] == "UNMAPPED" for r in rows)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
