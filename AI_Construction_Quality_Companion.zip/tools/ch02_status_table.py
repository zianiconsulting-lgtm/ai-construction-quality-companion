#!/usr/bin/env python3
"""Chapter 2 companion tool: submittal and material status table (fictional teaching example).

Prepares, deterministically, the table that the AI tool is given in Chapter 2. It keeps four things
apart for every cast (one row per cast on a delivery line):
  1. certificate   - document completeness: the certificate(s) in the certificate log for the cast,
                     with duplicates linked and counted once; "None recorded" (complete log only) or
                     "Not in the supplied extract (may exist; confirm)" (when --certs-extract is given);
  2. status        - every status recorded, with its record ID and date, for the product-submittal
                     revisions submitted by the time the cast was fixed (or by the cut-off if no fixing
                     is recorded); a status recorded after the fixing is shown, tagged "after fixing";
  3. condition     - the rule result of SPEC-QA-01.9 ("Materials shall not be used before status A or
                     B is recorded") read from the latest status recorded BEFORE the fixing for the
                     revision current at fixing: Met / Not met / "Not determinable — confirm" /
                     "Not determinable: same day, order unknown; confirm". A status recorded after the
                     fixing never establishes earlier permission. A missing certificate or record never
                     changes the result;
  certificate_review (supporting column) - the certificate review record(s) (ITP-FRM03.5) in the
                     inspections input that name the cast or its delivery note, or, failing that, name only
                     the location where the cast is fixed (labelled "names the location only"); if none:
                     "Not in the supplied extract (may exist; confirm)" with --inspections-extract,
                     otherwise "None recorded";
  4. containment   - only records that name the cast or its delivery: inspections with the result
                     "Not accepted", and communication records (labelled as such).

INPUTS (CSV files with the same columns as the Chapter 2 datasets):
  --submittals     ch02_submittals.csv            --requirements  ch02_submittal_requirements.csv
  --deliveries     ch02_deliveries.csv            --certs         ch02_mill_certs.csv
  --fixing         ch02_fixing_log.csv (optional: if omitted, locations read "Not provided")
  --inspections    inspections.csv (optional)     --communications ch02_communications.csv (optional)
  --clarifications optional CSV of project rules or recorded clarifications on whether an earlier
                   revision's status applies to a later revision (columns: record_id, basis ["project
                   rule" | "recorded clarification"], submittal_id, status_revision, applies_to_revision,
                   scope ["all" or cast / delivery IDs separated by ";"], use_from_week, use_from_day,
                   use_to_week, use_to_day [blank = open], recorded_week, recorded_day, recorded_time,
                   recorded_by_role, effect ["status applies" | "status does not apply"])
  Optional columns: status_time and submitted_time (submittals), time (fixing log), as HH:MM.
  --product        the product submittal that covers every delivery line in the file (e.g. SUB-FRM-001)
  --cutoff         "WEEK DAY" (e.g. "4 Tuesday"), inclusive; later records are excluded and counted
  --certs-extract  flag: the certificate log is an extract, not the complete log to the cut-off
  --inspections-extract  flag: the inspections input is an extract, not the complete log to the cut-off
OUTPUTS:
  --cast-csv       one row per cast (the four things above, plus delivery and fixing)
  --submittal-csv  one row per submittal revision: documents included / not included, n of N, status
  --md             Markdown: both tables, the counts, text found in delivery records, excluded records
                   (printed to standard output if --md is not given)

CONVENTIONS (author recommendation, stated so a person can check them):
  - Revision current at a date: the latest revision submitted on or before that day. If a revision
    was submitted on the same day as the fixing and no times order them: "Not determinable: same day,
    order unknown; confirm".
  - A status counts only if recorded before the fixing: an earlier day, or the same day with both
    times recorded and the status time earlier. Same day without two different times: "Not
    determinable: same day, order unknown; confirm", never "Met". With no fixing recorded, statuses
    recorded on or before the cut-off day count. Statuses recorded after the cut-off are excluded.
  - Earlier status A or B, current revision with no status before the fixing: the earlier status is
    neither carried forward nor cancelled. Only a project rule or recorded clarification (--clarifications)
    that covers that revision, the cast or its delivery, and the date of use, and that was recorded before
    the fixing, settles it, and its record ID is given; otherwise "Not determinable — confirm".
  - Records are matched to casts by ID text only (cast number, or delivery note when the record names
    no cast of that delivery). A record that names only a location is not matched.

WHAT A PERSON MUST STILL CHECK (the table is "prepared by script, checked by [role]"):
  - the inputs are the right files, revisions and cut-off, and the extract flag is set correctly;
  - the --product mapping is right for every delivery line;
  - each certificate is for that cast (the script matches IDs; it does not read certificates);
  - each certificate review record listed really reviewed that cast's certificates, above all a record
    matched by location only (a bay may hold bars from more than one delivery), and the inspections
    extract flag is right (with a complete log, "None recorded" is a gap in the ITP record);
  - each fixing entry and each matched record really refers to that cast, and each record listed under
    containment really records a containment action; records naming only a location are found by hand;
  - every "Not determinable" result is confirmed with the role that records statuses, and each
    clarification used really covers that revision, material and date.
The script decides nothing: it grants no status, releases nothing and directs no containment.
Python 3 standard library only; deterministic (rows keep the order of the delivery file).
"""
import argparse, csv, io, pathlib, re, sys

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
CAST_COLS = ["cast_no", "delivery_note", "received", "certificate", "certificate_review", "fixed", "status_basis",
             "status_recorded", "spec_qa_01_9", "condition_detail", "containment_recorded"]
SUB_COLS = ["submittal_rev", "revision_state", "included", "not_included", "count", "status_recorded"]


SAME_DAY = "Not determinable: same day, order unknown; confirm"
CONFIRM = "Not determinable — confirm"
AB = ("A", "B")


def when(week, day):
    return (int(week), DAYS.index(day.strip()))


def minutes(t):
    """'HH:MM' -> minutes after midnight; blank or unreadable -> None (no time recorded)."""
    m = re.fullmatch(r"\s*(\d{1,2}):(\d{2})\s*", t or "")
    return int(m.group(1)) * 60 + int(m.group(2)) if m else None


def moment(week, day, time=""):
    return when(week, day) + (minutes(time),)


def order(a, b):
    """Is moment a before, after, or not orderable against moment b? Same day: only two different times order it."""
    if a[:2] != b[:2]:
        return "before" if a[:2] < b[:2] else "after"
    if a[2] is not None and b[2] is not None and a[2] != b[2]:
        return "before" if a[2] < b[2] else "after"
    return "unknown"


def read(path):
    return list(csv.DictReader(open(path, newline="", encoding="utf-8"))) if path else None


def split_ids(s):
    return [x.strip() for x in (s or "").split(";") if x.strip()]


def date_text(w, d, t=""):
    return f"Week {w}, {d}" + (f" {t.strip()}" if (t or "").strip() else "")


def status_records(rows):
    """The recorded statuses among the register rows of one revision (a revision may have several over time)."""
    return [r for r in rows if r["review_status"]]


def status_moment(r):
    return moment(r["status_week"], r["status_day"], r.get("status_time", ""))


def status_text(s):
    return f"{s['review_status']} ({s['status_record']}, {date_text(s['status_week'], s['status_day'], s.get('status_time', ''))})"


def history(by_rev, revs_shown, rel):
    """Every recorded status of each revision shown, with its date; tagged when not before the reference."""
    out = []
    for rv in revs_shown:
        recs = sorted(status_records(by_rev[rv]), key=lambda r: _key(status_moment(r)))
        tags = {"after": "; after fixing", "unknown": "; same day as fixing, order not recorded"}
        txt = ", then ".join(status_text(r)[:-1] + tags.get(rel(status_moment(r)), "") + ")" for r in recs)
        out.append(f"rev {rv}: {txt or 'Not recorded'}")
    return "; ".join(out)


def _key(m):
    return (m[0], m[1], -1 if m[2] is None else m[2])


def latest_before(recs, rel):
    """(latest status record before the reference, ambiguous?) among recs. Ambiguous when two records share the
    latest moment (no time orders them) and only one of them is A or B."""
    before = [r for r in recs if rel(status_moment(r)) == "before"]
    if not before:
        return None, False
    top = max(_key(status_moment(r)) for r in before)
    tied = [r for r in before if _key(status_moment(r)) == top or
            (status_moment(r)[:2] == top[:2] and (status_moment(r)[2] is None or top[2] == -1))]
    ambiguous = len({r["review_status"] in AB for r in tied}) > 1
    return max(before, key=lambda r: _key(status_moment(r))), ambiguous


def covers(scope, d):
    ids = split_ids(scope)
    return any(x.lower() == "all" for x in ids) or d["cast_no"] in ids or d["delivery_note"] in ids


def carry_over(clars, product, from_rev, to_rev, d, ref, rel):
    """Project rules or recorded clarifications that settle whether rev from_rev's status applies to rev to_rev for
    this cast at the date of use. Returns (usable records, records not usable with the reason)."""
    usable, other = [], []
    for c in clars or []:
        if (c["submittal_id"] != product or str(c["status_revision"]) != str(from_rev)
                or str(c["applies_to_revision"]) != str(to_rev) or not covers(c["scope"], d)):
            continue
        lo = when(c["use_from_week"], c["use_from_day"]) if c.get("use_from_week") else None
        hi = when(c["use_to_week"], c["use_to_day"]) if c.get("use_to_week") else None
        if (lo and ref[:2] < lo) or (hi and ref[:2] > hi):
            other.append((c, "date of use outside its period")); continue
        if c.get("recorded_week"):
            r = rel(moment(c["recorded_week"], c["recorded_day"], c.get("recorded_time", "")))
            if r == "after":
                other.append((c, "recorded after fixing")); continue
            if r == "unknown":
                other.append((c, "recorded the same day, order not recorded")); continue
        elif c["basis"] != "project rule":
            other.append((c, "no record date")); continue
        usable.append(c)
    return usable, other


def condition(revs, ref, ref_label, d=None, clarifications=None, product="", at_cutoff=False):
    """SPEC-QA-01.9 rule result for the revision current at ref = (week, day, minutes or None).
    revs: register rows of one submittal (several rows of one revision = several status records over time).
    Only statuses recorded before the reference count (on or before the day at the cut-off); a status recorded
    after the fixing never establishes earlier permission. An earlier revision's A or B is neither carried
    forward nor cancelled: only a project rule or a recorded clarification covering the revision, the cast or
    its delivery, and the date of use settles it; otherwise "Not determinable — confirm"."""
    rel = (lambda m: "before" if m[:2] <= ref[:2] else "after") if at_cutoff else (lambda m: order(m, ref))
    by_rev = {}
    for r in revs:
        by_rev.setdefault(int(r["revision"]), []).append(r)
    sub_rel = {rv: rel(moment(rows[0]["submitted_week"], rows[0]["submitted_day"], rows[0].get("submitted_time", "")))
               for rv, rows in by_rev.items()}
    on_or_before = sorted(rv for rv in by_rev if sub_rel[rv] != "after")
    if not on_or_before:
        return "", "Not recorded", "Not met", "no revision submitted by that date"
    cur = on_or_before[-1]
    basis = f"{by_rev[cur][0]['submittal_rev']}, {ref_label}"
    st = history(by_rev, on_or_before, rel)
    if sub_rel[cur] == "unknown" and len(on_or_before) > 1:
        return basis, st, SAME_DAY, f"rev {cur} submitted the same day; order not recorded"
    recs = status_records(by_rev[cur])
    same = [r for r in recs if rel(status_moment(r)) == "unknown"]
    if same:
        return (basis, st, SAME_DAY,
                f"rev {cur}: {same[0]['review_status']} recorded the same day as the fixing ({same[0]['status_record']}); "
                "order not recorded")
    last, ambiguous = latest_before(recs, rel)
    when_txt = "by the cut-off" if at_cutoff else "before fixing"
    if ambiguous:
        return basis, st, CONFIRM, f"rev {cur}: two statuses recorded the same day, order not recorded"
    if last is not None:
        res = "Met" if last["review_status"] in AB else "Not met"
        return basis, st, res, f"{last['review_status']} recorded {when_txt}, {last['status_record']}"
    later = sorted((r for r in recs if rel(status_moment(r)) == "after"), key=lambda r: _key(status_moment(r)))
    late_txt = (f"; {later[0]['review_status']} recorded after fixing ({later[0]['status_record']}) does not count"
                if later else "")
    for e in reversed(on_or_before[:-1]):                     # latest earlier revision with a status before ref
        prev, amb = latest_before(status_records(by_rev[e]), rel)
        if prev is None:
            continue
        if prev["review_status"] not in AB:
            break
        usable, other = carry_over(clarifications, product, e, cur, d, ref, rel)
        if usable and len({c["effect"] for c in usable}) == 1:
            c = usable[0]
            res = "Met" if c["effect"] == "status applies" else "Not met"
            return (basis, st, res, f"no status for rev {cur} {when_txt}{late_txt}; rev {e} {prev['review_status']} "
                    f"({prev['status_record']}): {c['effect']} to rev {cur} for this cast and date, "
                    f"{c['record_id']} ({c['basis']}, {c['recorded_by_role'] or 'role not stated'})")
        why = ("conflicting records: " + "; ".join(c["record_id"] for c in usable)) if usable else \
              ("no project rule or recorded clarification covers this revision, cast and date"
               + ("".join(f"; {c['record_id']} not used ({w})" for c, w in other)))
        return (basis, st, CONFIRM, f"no status for rev {cur} {when_txt}{late_txt}; rev {e} has "
                f"{prev['review_status']} ({prev['status_record']}); {why}")
    return basis, st, "Not met", f"no A or B recorded {when_txt}{late_txt}"


def build(submittals, requirements, deliveries, certs, product, cutoff, fixing=None,
          inspections=None, communications=None, certs_extract=False, inspections_extract=False, review_item="ITP-FRM03.5",
          clarifications=None):
    """Return (cast_rows, submittal_rows, info). cutoff = (week, day index), inclusive."""
    inside = lambda r: when(r["week"], r["day"]) <= cutoff
    info = {"excluded": {}}
    if fixing is not None:
        info["excluded"]["fixing entries"] = sum(not inside(f) for f in fixing)
        fixing = [f for f in fixing if inside(f)]
    if inspections is not None:
        info["excluded"]["inspection records"] = sum(not inside(r) for r in inspections)
        inspections = [r for r in inspections if inside(r)]
    if communications is not None:
        info["excluded"]["communication records"] = sum(not inside(c) for c in communications)
        communications = [c for c in communications if inside(c)]
    certs = [c for c in certs if when(c["received_week"], c["received_day"]) <= cutoff]
    subs = [dict(s) for s in submittals if when(s["submitted_week"], s["submitted_day"]) <= cutoff]
    late = [s for s in subs if s["review_status"] and when(s["status_week"], s["status_day"]) > cutoff]
    info["excluded"]["status records"] = len(late) + sum(
        1 for s in submittals if s["review_status"] and when(s["submitted_week"], s["submitted_day"]) > cutoff)
    for s in late:                                   # a status recorded after the cut-off is not yet recorded
        s.update(review_status="", status_recorded_by_role="", status_week="", status_day="", status_record="")
    if clarifications is not None:
        clarifications = [c for c in clarifications if not c.get("recorded_week")
                          or when(c["recorded_week"], c["recorded_day"]) <= cutoff]

    # submittal completeness and recorded status, per revision
    sub_rows, by_rev = [], {}
    for s in subs:                                   # several rows of one revision = several status records
        by_rev.setdefault(s["submittal_rev"], []).append(s)
    for recs in sorted(by_rev.values(), key=lambda x: (x[0]["submittal_id"], int(x[0]["revision"]))):
        s = recs[0]
        recorded = sorted(status_records(recs), key=lambda r: _key(status_moment(r)))
        need = [r["req_id"] for r in requirements if r["applies_to"].startswith(s["submittal_id"] + " ")]
        inc = split_ids(s["documents_included"])
        latest = max(int(x["revision"]) for x in subs if x["submittal_id"] == s["submittal_id"])
        sub_rows.append({
            "submittal_rev": s["submittal_rev"],
            "revision_state": "Latest" if int(s["revision"]) == latest else "History",
            "included": "; ".join(x for x in need if x in inc) or "None",
            "not_included": "; ".join(x for x in need if x not in inc) or "None",
            "count": f"{sum(x in inc for x in need)} of {len(need)}",
            "status_recorded": "; ".join(
                f"{r['review_status']}, {r['status_recorded_by_role']}, "
                f"{date_text(r['status_week'], r['status_day'], r.get('status_time', ''))} ({r['status_record']})"
                for r in recorded) or "Not recorded"})

    revs = [s for s in subs if s["submittal_id"] == product]
    deliveries_by_dn = {}
    for d in deliveries:
        deliveries_by_dn.setdefault(d["delivery_note"], []).append(d["cast_no"])

    def named(text, d):
        if re.search(rf"\b{re.escape(d['cast_no'])}\b", text):
            return True
        others = deliveries_by_dn[d["delivery_note"]]
        return (re.search(rf"\b{re.escape(d['delivery_note'])}\b", text) is not None
                and not any(re.search(rf"\b{re.escape(c)}\b", text) for c in others))

    rows, remarks = [], []
    for d in deliveries:
        mine = [c for c in certs if c["cast_no"] == d["cast_no"]]
        uniq = [c["cert_id"] for c in mine if not c["duplicate_of"]]
        dups = [f"{c['cert_id']} duplicate of {c['duplicate_of']}" for c in mine if c["duplicate_of"]]
        if uniq:
            cert = "; ".join(uniq) + (f" ({'; '.join(dups)}, counted once)" if dups else "")
        elif certs_extract:
            entered = split_ids(d["mill_cert"])
            cert = ((f"Entered on delivery line: {'; '.join(entered)}; " if entered else "None entered on delivery line; ")
                    + "not in the supplied extract (may exist; confirm)")
        else:
            cert = "None recorded"
        if fixing is None:
            fixed, ref, label = "Not provided - confirmation required (fixing log not supplied)", cutoff, "at the cut-off"
            at_cut = True
        else:
            fx = [f for f in fixing if f["cast_no"] == d["cast_no"]]
            if fx:
                f = fx[0]
                fixed = f"{f['location']} ({f['fix_id']}; {f['fixed']})"
                ref, label = moment(f["week"], f["day"], f.get("time", "")), f"current when fixed ({f['fix_id']})"
                at_cut = False
            else:
                fixed, ref, label = "No fixing recorded", cutoff, "current at the cut-off (no fixing recorded)"
                at_cut = True
        if at_cut:
            ref = tuple(ref[:2]) + (None,)
        basis, st, cond, detail = condition(revs, ref, label, d, clarifications, product, at_cutoff=at_cut)
        revs_ins = [r for r in (inspections or []) if r["itp_item"] == review_item]
        rv = [r for r in revs_ins if named(f"{r['element']} {r['remarks']}", d)]
        loc = (fx[0]["location"] if fixing is not None and fx else None)
        rv_loc = [r for r in revs_ins if not rv and loc and r["element"].strip() == loc]
        review = "; ".join([f"{r['inspection_id']} ({r['result']})" for r in rv]
                           + [f"{r['inspection_id']} ({r['result']}; names the location only)" for r in rv_loc])
        if not review:
            review = "Not in the supplied extract (may exist; confirm)" if inspections_extract else "None recorded"
        cont = [f"{r['inspection_id']} (inspection: {r['result']})" for r in (inspections or [])
                if r["result"] == "Not accepted" and named(f"{r['element']} {r['remarks']}", d)]
        cont += [f"{c['comm_id']} (communication record)" for c in (communications or []) if named(c["content"], d)]
        rows.append({"cast_no": d["cast_no"], "delivery_note": d["delivery_note"], "received": d["received"],
                     "certificate": cert, "certificate_review": review, "fixed": fixed, "status_basis": basis, "status_recorded": st,
                     "spec_qa_01_9": cond, "condition_detail": detail,
                     "containment_recorded": "; ".join(cont) or "None recorded"})
        if d["remarks"]:
            remarks.append(f"{d['line_id']} ({d['delivery_note']}): \"{d['remarks']}\"")
    nocert = [r for r, d in zip(rows, deliveries) if not any(c["cast_no"] == d["cast_no"] for c in certs)]
    ext = " in the supplied extract" if certs_extract else ""
    info["counts"] = {"casts": len(deliveries), "certificate records" + ext: len(certs),
                      "unique certificates" + ext: sum(1 for c in certs if not c["duplicate_of"]),
                      "casts with no certificate" + ext: len(nocert)}
    if fixing is not None:
        info["counts"]["of those, fixed"] = sum(1 for r in nocert if r["fixed"] != "No fixing recorded")
    info["remarks"] = remarks
    info["certs_extract"] = certs_extract
    info["review_item"] = review_item
    info["inspections_extract"] = inspections_extract
    return rows, sub_rows, info


def to_csv(rows, cols):
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=cols, lineterminator="\n")
    w.writeheader(); w.writerows(rows)
    return buf.getvalue()


def to_md(rows, sub_rows, info, cutoff_label, product, checker="[role]"):
    t = [f"STATUS TABLE - prepared by script (ch02_status_table.py), checked by {checker}",
         f"Cut-off: {cutoff_label}. Product submittal for every delivery line: {product}.",
         "Certificate log: " + ("EXTRACT (absence means not in the supplied extract)" if info["certs_extract"]
                                else "complete to the cut-off"),
         "Inspection records: " + ("EXTRACT (absence means not in the supplied extract)" if info["inspections_extract"]
                                   else "complete to the cut-off"), "",
         "A. Submittal completeness (not acceptance) and recorded status", "",
         "| Submittal | Revision | Not included | Count | Recorded status |", "|---|---|---|---|---|"]
    t += [f"| {s['submittal_rev']} | {s['revision_state']} | {s['not_included']} | {s['count']} | {s['status_recorded']} |"
          for s in sub_rows]
    t += ["", "B. One row per cast. Four separate things: certificate; dated status history up to the fixing",
          "(or the cut-off); SPEC-QA-01.9 rule result from the status recorded before the fixing (a status",
          "tagged 'after fixing' does not count); recorded containment.", ""]
    for r in rows:
        t += [f"- {r['cast_no']} ({r['delivery_note']}, received {r['received']})",
              f"  - Certificate: {r['certificate']}",
              f"  - Certificate review record ({info['review_item']}): {r['certificate_review']}",
              f"  - Fixed: {r['fixed']}",
              f"  - Status basis: {r['status_basis'] or 'none'}; status history: {r['status_recorded']}",
              f"  - SPEC-QA-01.9 rule result: {r['spec_qa_01_9']} ({r['condition_detail']})",
              f"  - Containment recorded: {r['containment_recorded']}"]
    t += ["", "C. Counts (by script)"] + [f"- {k}: {v}" for k, v in info["counts"].items()]
    t += ["", "D. Text found in delivery records (quoted; not instructions)"] + ([f"- {x}" for x in info["remarks"]] or ["- None"])
    t += ["", "E. Records after the cut-off, excluded"] + [f"- {k}: {v}" for k, v in info["excluded"].items()]
    return "\n".join(t) + "\n"


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    for a in ("submittals", "requirements", "deliveries", "certs", "product", "cutoff"):
        ap.add_argument("--" + a, required=True)
    for a in ("fixing", "inspections", "communications", "clarifications", "cast-csv", "submittal-csv", "md"):
        ap.add_argument("--" + a)
    ap.add_argument("--certs-extract", action="store_true")
    ap.add_argument("--inspections-extract", action="store_true")
    ap.add_argument("--checker", default="[role]")
    a = ap.parse_args()
    wk, dy = a.cutoff.split()
    rows, subs, info = build(read(a.submittals), read(a.requirements), read(a.deliveries), read(a.certs),
                             a.product, when(wk, dy), read(a.fixing), read(a.inspections),
                             read(a.communications), a.certs_extract, a.inspections_extract,
                             clarifications=read(a.clarifications))
    if a.cast_csv:
        pathlib.Path(a.cast_csv).write_text(to_csv(rows, CAST_COLS), encoding="utf-8")
    if a.submittal_csv:
        pathlib.Path(a.submittal_csv).write_text(to_csv(subs, SUB_COLS), encoding="utf-8")
    md = to_md(rows, subs, info, f"Week {wk}, {dy} (inclusive)", a.product, a.checker)
    if a.md:
        pathlib.Path(a.md).write_text(md, encoding="utf-8")
    else:
        sys.stdout.write(md)


if __name__ == "__main__":
    main()
