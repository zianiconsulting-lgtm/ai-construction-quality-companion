#!/usr/bin/env python3
"""Chapter 4 companion tool: the two checked tables behind a weekly quality report.

Python 3 standard library only. Deterministic: the same CSVs and arguments always give the same files.

WHAT IT DOES
It keeps two scopes apart that a weekly report must never mix:
  Table A, WEEKLY ACTIVITY: records whose inspection (event) date is in the week covered and whose
    submission was entered by the cut-off, counted once per record ID. Earlier-week events, entries
    after the cut-off and duplicate submissions are listed with a reason, never counted.
  Table B, OUTSTANDING POSITION AT THE CUT-OFF: every hold point with no release recorded and every
    NCR with no "Closed" event, whatever week it arose in. Earlier-week items appear here but are
    never counted as this week's activity.

INPUTS (CSV files with the column names of the book's datasets; your own files may be used if
they have the same columns)
  inspections.csv       inspection_id, week, day, itp_item, element, result, recorded_by_role,
                        released_by_role, remarks; optional time ("HH:MM")
  itp_items.csv         itp_item, package, point_type (Hold, Witness, Surveillance, Review)
  ncrs.csv              ncr_id, raised_week, raised_day, source_inspection, location
  ncr_events.csv        ncr_id, week, day, event, detail, by_role, record_id (in date order);
                        optional time ("HH:MM")
  submission log        submission_id, inspection_id, submitted_week, submitted ("Day HH:MM"),
                        duplicate_of; optional result_as_submitted
  --week N --cutoff "Friday 12:00"   the week covered and the cut-off in that week

OUTPUTS (in --out, file names start with --prefix)
  <prefix>activity.csv     one row per submission: the record's fields and a status
  <prefix>counts.csv       section, measure, count, records: the reconciliation and the counts
  <prefix>outstanding.csv  one row per open hold point or open NCR at the cut-off
  With --md, the same tables are also printed as Markdown.

RULES APPLIED (author recommendations, stated in Chapter 4)
  - A submission counts only if its record's event week is the week covered and it was entered
    by the cut-off. Only the first in-scope submission of a record ID counts; later ones are
    duplicates (linked or not). If submissions of one record differ in result_as_submitted, or
    differ from the register result, the record is counted with its result "Unresolved".
  - Timing against the cut-off is settled by week, then day, then time. A record or event on a
    later day of the week covered, or in a later week, is after the cut-off. On the cut-off day
    itself, a time settles the order; with no time it is "timing uncertain: confirm", never guessed.
  - A record is in the register at the cut-off only if its event is not after the cut-off and,
    where the submission log has an entry for it, its first entry is by the cut-off (whatever
    week the event was in). A record with no log entry is taken as held from its event date.
  - A hold point is a record on an ITP item whose point type is Hold. It is released at the
    cut-off only if a release dated by the cut-off is recorded: on the record (released_by_role
    filled; dated by its HPR event in the NCR log, else by a "Week N Day" in the remarks, else by
    the record itself), or as a "Hold point released" event of an NCR whose source_inspection is
    that record. A release dated after the cut-off does not count. Otherwise it is outstanding.
  - An NCR is outstanding if it has an event held at the cut-off and no "Closed" event held at the
    cut-off. Its position is its latest event held at the cut-off. Events on the cut-off day with
    no time mark the row "timing uncertain: confirm" and are not used.

WHAT A PERSON MUST STILL CHECK (the tool does not know)
  - That the export is complete and current, and the cut-off and week are the ones the reporting
    rule states.
  - That no hold point was released by a later record the tool cannot link (a re-inspection with
    no NCR link, or a release recorded elsewhere), and that no release recorded here was
    withdrawn.
  - Every "Unresolved" record, every "timing uncertain: confirm" row and every warning, with the
    person who made the record; and that an undated release on a record was given by the cut-off.
  - That an item listed as outstanding really is the same hold point or NCR, and nothing outside
    these files (paper records, e-mails) changes the position. Then sign the tables as checked.
  The tool reports records. It never accepts, releases or closes anything.

USAGE
  python3 ch04_weekly_tables.py --data ../datasets --week 10 --cutoff "Friday 12:00" --out . --md
"""
import argparse, csv, pathlib, re, sys

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
ACT_COLS = ["submission_id", "inspection_id", "event_week", "event_day", "entered", "itp_item",
            "point_type", "package", "element", "result", "released_by_role", "release_record",
            "ncr", "status"]
CNT_COLS = ["section", "measure", "count", "records"]
UNCERTAIN = "Timing uncertain: confirm"
OUT_COLS = ["item", "kind", "arose", "location", "link", "latest_event", "latest_when",
            "latest_by", "latest_record", "correction_verified", "position", "new_this_week"]


def read(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def minutes(day, hhmm):
    h, m = hhmm.split(":")
    return DAYS.index(day) * 1440 + int(h) * 60 + int(m)


def ids_text(ids):
    """Compact list: RS-101 to RS-112 when consecutive, otherwise comma-separated."""
    ids = list(ids)
    if len(ids) > 3:
        m = [re.fullmatch(r"([A-Z]+-)(\d+)", i) for i in ids]
        if all(m) and len({x.group(1) for x in m}) == 1:
            n = [int(x.group(2)) for x in m]
            if n == list(range(n[0], n[0] + len(n))):
                return f"{ids[0]} to {ids[-1]}"
    return ", ".join(ids)


def build(data, week, cutoff, submissions=None, trace=None):
    """Return (activity_rows, count_rows, outstanding_rows, warnings). If a dict is passed as
    trace, it receives each hold-point record's decision (the categories of the spreadsheet method)."""
    trace = {} if trace is None else trace
    data = pathlib.Path(data)
    ins = {r["inspection_id"]: r for r in read(data / "inspections.csv")}
    itp = {r["itp_item"]: r for r in read(data / "itp_items.csv")}
    ncrs = read(data / "ncrs.csv")
    events = read(data / "ncr_events.csv")
    subs = read(pathlib.Path(submissions) if submissions else data / "ch04_submitted_records.csv")
    cday, ctime = cutoff.split()
    cut_abs = (week, minutes(cday, ctime))
    warnings = []

    def timing(wk, day, hhmm=""):
        """'before' (held at the cut-off), 'after', or 'uncertain' (cut-off day, no time)."""
        d = (int(wk), DAYS.index(day))
        if d != (week, DAYS.index(cday)):
            return "before" if d < (week, DAYS.index(cday)) else "after"
        if not (hhmm or "").strip():
            return "uncertain"
        return "before" if minutes(day, hhmm.strip()) <= cut_abs[1] else "after"

    ev_t = lambda e: timing(e["week"], e["day"], e.get("time", ""))
    held_ev = [e for e in events if ev_t(e) == "before"]
    unc_ev = [e for e in events if ev_t(e) == "uncertain"]
    if unc_ev:
        warnings.append(f"{len(unc_ev)} NCR event(s) on {cday} of Week {week} have no time; not treated as held; "
                        "rows marked 'timing uncertain: confirm'. Check them.")
    entry_of = {}  # first entry of each record in the submission log
    for s in subs:
        k = (int(s["submitted_week"]), minutes(*s["submitted"].split()))
        if s["inspection_id"] not in entry_of or k < entry_of[s["inspection_id"]][0]:
            entry_of[s["inspection_id"]] = (k, s)

    def available(r):
        """Was the record in the register at the cut-off? Uses the log's entry time where it exists."""
        t = timing(r["week"], r["day"], r.get("time", ""))
        if t == "after" or r["inspection_id"] not in entry_of:
            return t
        k, s = entry_of[r["inspection_id"]]
        return "before" if k <= cut_abs else "after"

    def record_release(r):
        """(timing, basis) of a release recorded on the record, or None. Date from a linked HPR
        event in the NCR log, else a 'Week N Day [HH:MM]' in the remarks, else the record itself."""
        if not r["released_by_role"]:
            return None
        hpr = re.findall(r"HPR-\d+", r.get("remarks", ""))
        hev = [e for e in events if e["record_id"] in hpr and e["record_id"]]
        if hev:
            return ev_t(hev[0]), f"{hev[0]['record_id']} dated Week {hev[0]['week']} {hev[0]['day']}"
        m = re.search(r"Week (\d+) (" + "|".join(DAYS) + r")(?: (\d{1,2}:\d{2}))?", r.get("remarks", ""))
        if m:
            return timing(m.group(1), m.group(2), m.group(3) or ""), f"release dated Week {m.group(1)} {m.group(2)}"
        return available(r), "release on the record, undated"

    ncr_of = {}
    for n in ncrs:
        if n.get("source_inspection"):
            ncr_of.setdefault(n["source_inspection"], []).append(n["ncr_id"])

    def release_record(r):
        m = re.findall(r"HPR-\d+", r.get("remarks", ""))
        return m[0] if m else ("on the record" if r["released_by_role"] else "")

    # ---- Table A: weekly activity ----
    act, first, seen_rows = [], {}, {}
    for s in sorted(subs, key=lambda s: (int(s["submitted_week"]), minutes(*s["submitted"].split()))):
        r = ins.get(s["inspection_id"])
        base = {"submission_id": s["submission_id"], "inspection_id": s["inspection_id"],
                "entered": f"Week {s['submitted_week']} {s['submitted']}"}
        if r is None:
            act.append({**base, "status": "Not counted: record not in the register - confirm"})
            warnings.append(f"{s['submission_id']}: {s['inspection_id']} is not in the register.")
            continue
        it = itp.get(r["itp_item"], {})
        row = {**base, "event_week": r["week"], "event_day": r["day"], "itp_item": r["itp_item"],
               "point_type": it.get("point_type", ""), "package": it.get("package", ""),
               "element": r["element"], "result": r["result"],
               "released_by_role": r["released_by_role"], "release_record": release_record(r),
               "ncr": ", ".join(ncr_of.get(r["inspection_id"], []))}
        entered_abs = (int(s["submitted_week"]), minutes(*s["submitted"].split()))
        if int(r["week"]) < week:
            row["status"] = f"Not counted: event in Week {r['week']} (late entry for Week {r['week']})"
        elif int(r["week"]) > week:
            row["status"] = f"Not counted: event in Week {r['week']}"
        elif entered_abs > cut_abs:
            row["status"] = f"Not counted: entered after the cut-off (late entry for Week {week}, next report)"
        elif r["inspection_id"] in first:
            f0 = first[r["inspection_id"]]
            link = "" if s.get("duplicate_of") else "; no link entered in the log"
            row["status"] = f"Not counted: duplicate of {f0['submission_id']} (same record ID{link})"
            seen_rows[r["inspection_id"]].append(s)
        else:
            row["status"] = "Counted"
            first[r["inspection_id"]] = row
            seen_rows[r["inspection_id"]] = [s]
        act.append(row)

    # conflicting submissions of one record: counted once, result unresolved
    if any("result_as_submitted" in s for s in subs):
        for rid, ss in seen_rows.items():
            vals = {s.get("result_as_submitted", "") for s in ss} | {ins[rid]["result"]}
            vals.discard("")
            if len(vals) > 1:
                first[rid]["result"] = "Unresolved"
                first[rid]["status"] = ("Counted, result unresolved: submissions "
                                        + ", ".join(s["submission_id"] for s in ss)
                                        + " and the register differ - not used until the recorder confirms")
                for a in act:
                    later_s = next((s for s in ss[1:] if s["submission_id"] == a["submission_id"]), None)
                    if later_s is not None:
                        a["result"] = later_s.get("result_as_submitted") or a["result"]
                        a["status"] += f"; result as submitted differs from {ss[0]['submission_id']}"
                warnings.append(f"{rid}: submissions differ ({sorted(vals)}).")

    counted = [first[k] for k in sorted(first, key=lambda k: act.index(first[k]))]
    n = len(counted)

    def subset(pred):
        return [a for a in act if pred(a)]

    earlier = subset(lambda a: a["status"].startswith("Not counted: event in Week"))
    late = subset(lambda a: a["status"].startswith("Not counted: entered after"))
    dups = subset(lambda a: a["status"].startswith("Not counted: duplicate"))
    other = subset(lambda a: a["status"].startswith("Not counted: record not"))
    held_subs = len(act) - len(earlier) - len(late) - len(other)
    pair = lambda rows: ", ".join(f"{a['submission_id']} ({a['inspection_id']})" for a in rows)
    R, S, T, O = "Reconciliation", "Results", "Releases and NCRs this week", "Outstanding"
    cnt = [
        (R, "Submissions in the log", str(len(act)), ids_text(a["submission_id"] for a in act)),
        (R, "Not counted: event in another week", str(len(earlier)), pair(earlier)),
        (R, "Not counted: entered after the cut-off", str(len(late)), pair(late)),
    ]
    if other:
        cnt.append((R, "Not counted: record not in the register", str(len(other)), pair(other)))
    cnt += [
        (R, f"Week {week} submissions held at the cut-off", str(held_subs), ""),
        (R, "Not counted: duplicate submissions", str(len(dups)), pair(dups)),
        (R, "Unique records counted", str(n), ", ".join(a["inspection_id"] for a in counted)),
    ]
    for res in ["Accepted", "Not accepted", "Unresolved"]:
        rr = [a["inspection_id"] for a in counted if a["result"] == res]
        if rr or res != "Unresolved":
            cnt.append((S, f"Result: {res}", f"{len(rr)} of {n}", ", ".join(rr) if res != "Accepted" else ""))
    other_res = [a["inspection_id"] for a in counted if a["result"] not in ("Accepted", "Not accepted", "Unresolved")]
    if other_res:
        cnt.append((S, "Result: other (as recorded)", f"{len(other_res)} of {n}", ", ".join(other_res)))
    for pt in ["Hold", "Witness", "Surveillance", "Review"]:
        k = sum(a["point_type"] == pt for a in counted)
        if k or pt != "Review":
            cnt.append((S, f"Point type: {pt}", f"{k} of {n}", ""))
    for pk in sorted({i["package"] for i in itp.values()}):
        cnt.append((S, f"Package: {pk}", f"{sum(a['package'] == pk for a in counted)} of {n}", ""))
    rel = [a for a in counted if a["point_type"] == "Hold" and a["released_by_role"]
           and (record_release(ins[a["inspection_id"]]) or ("",))[0] == "before"]
    cnt.append((T, "Hold point releases recorded this week", str(len(rel)),
                ", ".join(f"{a['inspection_id']} ({a['released_by_role']}"
                          + (f"; {a['release_record']})" if a["release_record"] != "on the record" else ")")
                          for a in rel)))
    iss = sorted({e["ncr_id"] for e in held_ev if e["event"] == "Issued" and int(e["week"]) == week})
    clo = sorted({e["ncr_id"] for e in held_ev if e["event"] == "Closed" and int(e["week"]) == week})
    cnt.append((T, "NCRs issued this week (event log)", str(len(iss)), ", ".join(iss)))
    cnt.append((T, "NCRs closed this week (event log)", str(len(clo)), ", ".join(clo)))

    # ---- Table B: outstanding position at the cut-off (any week) ----
    out, later, entered_late, uncertain = [], [], [], []
    for r in ins.values():
        it = itp.get(r["itp_item"], {})
        if it.get("point_type") != "Hold":
            continue
        avail = available(r)
        if avail == "after":
            if timing(r["week"], r["day"], r.get("time", "")) != "after":
                entered_late.append(r["inspection_id"])  # event by the cut-off, entered after it
                trace[r["inspection_id"]] = "Not in the position: entered after the cut-off"
            else:
                trace[r["inspection_id"]] = "Not in the position: after the cut-off"
            continue
        links = ncr_of.get(r["inspection_id"], [])
        on_rec = record_release(r)
        rels = [e for e in events if e["ncr_id"] in links and e["event"] == "Hold point released"]
        rel_t = [ev_t(e) for e in rels]
        if on_rec and on_rec[0] == "before":
            trace[r["inspection_id"]] = "Released on the record"
            continue  # released on its own record by the cut-off
        if "before" in rel_t:
            e = rels[rel_t.index("before")]
            trace[r["inspection_id"]] = "Released later (NCR log)"
            later.append(f"{r['inspection_id']}: released later, {e['record_id'] or 'release event'} ({e['ncr_id']} log, Week {e['week']} {e['day']})")
            continue
        notes = []
        for nid in links:
            c = [e for e in held_ev if e["ncr_id"] == nid and e["event"] == "Closed"]
            if c:
                notes.append(f"{nid} closed Week {c[-1]['week']} {c[-1]['day']}; a closure is not a release")
        after = ([on_rec[1]] if on_rec and on_rec[0] == "after" else []) + \
                [f"{e['record_id'] or 'release'} ({e['ncr_id']} log, Week {e['week']} {e['day']})" for e, t in zip(rels, rel_t) if t == "after"]
        unc = ([f"record {r['inspection_id']} dated {cday} with no time or entry"] if avail == "uncertain" else []) + \
              ([on_rec[1] + ", no time"] if on_rec and on_rec[0] == "uncertain" else []) + \
              [f"release {e['record_id'] or ''} ({e['ncr_id']} log, {e['day']}, no time)".replace("release  ", "release ")
               for e, t in zip(rels, rel_t) if t == "uncertain"]
        if unc:
            pos = f"{UNCERTAIN} - " + "; ".join(unc)
            uncertain.append(r["inspection_id"])
        elif after:
            pos = "Open: no release recorded at the cut-off; " + "; ".join(after) + ", after the cut-off"
        else:
            pos = "Open: no release recorded"
        trace[r["inspection_id"]] = pos.split(" - ")[0].split(";")[0]
        out.append({"item": r["inspection_id"], "kind": f"Hold point ({r['itp_item']})",
                    "arose": f"Week {r['week']} {r['day']}", "location": r["element"],
                    "link": ", ".join(links), "latest_event": f"Result {r['result']}; no release recorded",
                    "latest_when": f"Week {r['week']} {r['day']}", "latest_by": r["recorded_by_role"],
                    "latest_record": r["inspection_id"], "correction_verified": "",
                    "position": pos + ("; " + "; ".join(notes) if notes else ""),
                    "new_this_week": "Yes" if int(r["week"]) == week else "No"})
    for nc in ncrs:
        ev = [e for e in held_ev if e["ncr_id"] == nc["ncr_id"]]
        ue = [e for e in unc_ev if e["ncr_id"] == nc["ncr_id"]]
        if (not ev and not ue) or any(e["event"] == "Closed" for e in ev):
            continue
        last = ev[-1] if ev else {"event": "", "week": "", "day": "", "by_role": "", "record_id": ""}
        cv = [e for e in ev if e["event"] == "Correction verified"]
        cvt = f"Week {cv[-1]['week']} {cv[-1]['day']} ({cv[-1]['by_role']})" if cv else ""
        if ev:
            pos = f"Open: latest event {last['event']}, Week {last['week']} {last['day']} ({last['by_role']}"
            pos += (f"; {last['record_id']})" if last["record_id"] else ")") + "; no Closed event"
        else:
            pos = "No event held before the cut-off day"
        if ue:
            pos = f"{UNCERTAIN} - " + ", ".join(e["event"] for e in ue) + f" on {cday} with no time; " + pos
            uncertain.append(nc["ncr_id"])
        out.append({"item": nc["ncr_id"], "kind": "NCR", "arose": f"Week {nc['raised_week']} {nc['raised_day']}",
                    "location": nc["location"], "link": nc.get("source_inspection", ""),
                    "latest_event": last["event"], "latest_when": f"Week {last['week']} {last['day']}",
                    "latest_by": last["by_role"], "latest_record": last["record_id"],
                    "correction_verified": cvt, "position": pos,
                    "new_this_week": "Yes" if int(nc["raised_week"]) == week else "No"})
    key = lambda o: (0 if o["kind"] != "NCR" else 1, o["item"])
    out.sort(key=key)
    cnt.append((T, "Hold points not released on their record but released later", str(len(later)), "; ".join(later)))
    if entered_late:
        cnt.append((O, "Not in the position: hold-point records entered after the cut-off", str(len(entered_late)), ", ".join(entered_late)))
    hp = [o["item"] for o in out if o["kind"] != "NCR" and o["item"] not in uncertain]
    nn = [o["item"] for o in out if o["kind"] == "NCR" and o["item"] not in uncertain]
    cnt.append((O, "Outstanding at the cut-off: hold points (any week)", str(len(hp)), ", ".join(hp)))
    cnt.append((O, "Outstanding at the cut-off: NCRs not closed (any week)", str(len(nn)), ", ".join(nn)))
    if uncertain:
        cnt.append((O, "Outstanding at the cut-off: timing uncertain, confirm", str(len(uncertain)), ", ".join(uncertain)))
        warnings.append(f"Timing uncertain at the cut-off: {', '.join(uncertain)}. Confirm the order with the record keeper.")
    full = [{**{c: "" for c in ACT_COLS}, **a} for a in act]
    return full, [dict(zip(CNT_COLS, c)) for c in cnt], out, warnings


def write_csv(path, cols, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def md(cols, rows):
    esc = lambda v: str(v).replace("|", "/")
    return "\n".join(["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
                     + ["| " + " | ".join(esc(r.get(c, "")) or "(blank)" for c in cols) + " |" for r in rows])


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--data", required=True, help="folder with inspections.csv, itp_items.csv, ncrs.csv, ncr_events.csv")
    ap.add_argument("--submissions", help="submission log CSV (default: <data>/ch04_submitted_records.csv)")
    ap.add_argument("--week", type=int, required=True)
    ap.add_argument("--cutoff", required=True, help='day and time in the week covered, e.g. "Friday 12:00"')
    ap.add_argument("--out", default=".")
    ap.add_argument("--prefix", default="weekly_")
    ap.add_argument("--md", action="store_true", help="also print the tables as Markdown")
    a = ap.parse_args(argv)
    act, cnt, out, warn = build(a.data, a.week, a.cutoff, a.submissions)
    o = pathlib.Path(a.out)
    o.mkdir(parents=True, exist_ok=True)
    write_csv(o / f"{a.prefix}activity.csv", ACT_COLS, act)
    write_csv(o / f"{a.prefix}counts.csv", CNT_COLS, cnt)
    write_csv(o / f"{a.prefix}outstanding.csv", OUT_COLS, out)
    if a.md:
        print(f"## Table A - weekly activity, Week {a.week}, cut-off {a.cutoff}\n")
        print(md(ACT_COLS, act) + "\n\n" + md(CNT_COLS, cnt))
        print(f"\n## Table B - outstanding position at the cut-off (any week)\n")
        print(md(OUT_COLS, out))
    for w in warn:
        print("WARNING:", w, file=sys.stderr)
    print("Prepared by script. A person must check these tables against the register before use.", file=sys.stderr)


if __name__ == "__main__":
    main()
