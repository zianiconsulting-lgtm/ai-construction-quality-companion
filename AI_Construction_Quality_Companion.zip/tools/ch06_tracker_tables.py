#!/usr/bin/env python3
"""Chapter 6 companion tool: corrective-action and NCR status tables at a cut-off.

Python 3, standard library only. Deterministic: the same files and arguments always give the same output.

INPUTS (CSV files with the same columns as the book's files; other columns are ignored)
  --register  corrective-action register: ca_id, ncr_id, action, owner_role, due_week,
              reported_complete_week, verified_effective, verified_by_role, verification_record
  --ncrs      NCR log: ncr_id, raised_week, raised_day, requirement_ref
  --events    NCR events: ncr_id, week, day, event, detail, by_role, record_id
              (file order within a day is taken as the recorded order)
  --week, --day   the cut-off: records to the end of that day (day: Monday to Friday)
  --verifier  the role that the project rules authorise to verify effectiveness. Omit it if the
              rules you have do not name one: no entry is then shown as verified.
  --out-dir   folder for the outputs (created if needed)

OUTPUTS
  actions_status.csv  one row per action: ca_id, ncr_id, owner_role, due_week, status, weeks_overdue,
                      evidence, check_note
  ncr_status.csv      one row per NCR raised by the cut-off: ncr_id, raised, requirement_ref,
                      latest_event, correction_verified, closed
  report.md           the same two tables in Markdown, the counts, and every record or field left out
                      because it is dated after the cut-off

RULES APPLIED (fictional project rules in the book; change them only if your own rules differ)
  - An action whose NCR was raised after the cut-off is left out and listed.
  - A reported-complete week after the cut-off week is withheld, and so is the verification entry.
    A verification record dated "Week N [day]" after the cut-off is withheld.
  - Status, in this order: "Verified effective (recorded)" (result Yes, a record, and the --verifier
    role); "Verified not effective (recorded)" (result No); "Reported complete - awaiting verification";
    "Overdue - not reported complete" (cut-off week later than that action's own due week);
    "Open - not yet due". A Yes entry by another role, or by no role, stays "awaiting verification"
    and gets a check note.
  - NCR closure is read only from a "Closed" event; the "Correction verified" event is shown beside it.

WHAT A PERSON MUST STILL CHECK (the tool does not do this)
  - that the register and the event log are complete and current, and that each row belongs to its NCR;
  - every check note, including verification records with no date and reports in the cut-off week;
  - that the --verifier role is the one your contract and project rules authorise;
  - the counts, against the register, before the tables go to anyone or into an AI tool.
  The tool decides nothing: it does not verify, close or judge any action.

Example (from the book folder):
  python3 05_Companion/public/tools/ch06_tracker_tables.py --register 03_Datasets/ch06_ca_tracker_w14.csv \
    --ncrs 03_Datasets/ncrs.csv --events 03_Datasets/ncr_events.csv --week 14 --day Monday \
    --verifier "Client's Engineer" --out-dir out_ch06
"""
import argparse
import csv
import pathlib
import re

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
STATUSES = ["Verified effective (recorded)", "Verified not effective (recorded)",
            "Reported complete - awaiting verification", "Overdue - not reported complete", "Open - not yet due"]


def read(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def when(week, day):
    return (int(week), DAYS.index(day))


def record_date(text):
    """(week, day index or None) of the first 'Week N [day]' in a free-text record, or None."""
    m = re.search(r"Week (\d+)(?:,? (Monday|Tuesday|Wednesday|Thursday|Friday))?", text or "")
    if not m:
        return None
    return (int(m.group(1)), DAYS.index(m.group(2)) if m.group(2) else None)


def ncr_tables(ncrs, events, cut):
    """NCR rows raised by the cut-off, with latest event, correction verified and closed; plus exclusions."""
    kept = [n for n in ncrs if when(n["raised_week"], n["raised_day"]) <= cut]
    excluded_ncrs = [n["ncr_id"] for n in ncrs if n not in kept]
    ev = [e for e in events if when(e["week"], e["day"]) <= cut]
    excluded_events = [e for e in events if when(e["week"], e["day"]) > cut]
    out = []
    for n in kept:
        mine = [e for e in ev if e["ncr_id"] == n["ncr_id"]]
        last = mine[-1] if mine else None
        if last:
            rec = f" ({last['record_id']})" if last["event"] == "Disposition recorded" and last["record_id"] else ""
            latest = f"{last['event']}{rec}, Week {last['week']} {last['day']}, {last['by_role']}"
        else:
            latest = "No event recorded"

        def fmt(e):
            return f"Week {e['week']} {e['day']}, {e['by_role'] or 'role not recorded'}, {e['record_id'] or 'no record ID'}"
        cv = [e for e in mine if e["event"] == "Correction verified"]
        cl = [e for e in mine if e["event"] == "Closed"]
        out.append({"ncr_id": n["ncr_id"], "raised": f"Week {n['raised_week']}, {n['raised_day']}",
                    "requirement_ref": n["requirement_ref"], "latest_event": latest,
                    "correction_verified": fmt(cv[-1]) if cv else "Not recorded",
                    "closed": fmt(cl[-1]) if cl else "Not closed"})
    return out, excluded_ncrs, excluded_events


def action_table(register, ncrs, cut, verifier):
    raised = {n["ncr_id"]: when(n["raised_week"], n["raised_day"]) for n in ncrs}
    cw = cut[0]
    out, excluded, withheld = [], [], []
    for r in register:
        if r["ncr_id"] not in raised or raised[r["ncr_id"]] > cut:
            excluded.append(r["ca_id"])
            continue
        notes = []
        rep = r["reported_complete_week"]
        res, role, rec = r["verified_effective"], r["verified_by_role"], r["verification_record"]
        if rep and int(rep) > cw:
            withheld.append(f"{r['ca_id']}: reported complete Week {rep} (after the cut-off)")
            rep, res, role, rec = "", "", "", ""
        if rep and int(rep) == cw and cut[1] < 4:
            notes.append("reported in the cut-off week; day not recorded - confirm")
        d = record_date(rec)
        if rec and d and (d[0] > cw or (d[1] is not None and (d[0], d[1]) > cut)):
            withheld.append(f"{r['ca_id']}: verification record dated after the cut-off")
            res, role, rec = ("Not yet verified" if rep else ""), "", ""
        elif rec and not d:
            notes.append("verification record has no date - confirm it was recorded by the cut-off")
        if res == "Yes" and rec and verifier and role == verifier:
            status = STATUSES[0]
        elif res == "No" and rec:
            status = STATUSES[1]
        elif rep:
            status = STATUSES[2]
            if res == "Yes":
                notes.append(f"Yes recorded by {role or 'no role'}; the authorised verifier is "
                             f"{verifier or 'not provided'} - confirm")
            elif rec:
                notes.append("verification record present but result is not Yes - confirm")
        elif cw > int(r["due_week"]):
            status = STATUSES[3]
        else:
            status = STATUSES[4]
        if not rep and res in ("Yes", "No"):
            notes.append("verification recorded but no reported-complete week - confirm")
        overdue = cw - int(r["due_week"]) if status == STATUSES[3] else 0
        ev = []
        if rep:
            ev.append(f"Reported complete Week {rep}")
        if rec or role:
            ev.append(f"Verification: {res or 'blank'}; {role or 'no role'}; {rec or 'no record'}")
        out.append({"ca_id": r["ca_id"], "ncr_id": r["ncr_id"], "owner_role": r["owner_role"], "due_week": r["due_week"],
                    "status": status, "weeks_overdue": str(overdue), "evidence": ". ".join(ev) or "None recorded",
                    "check_note": "; ".join(notes)})
    return out, excluded, withheld


def md_table(rows, cols):
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    lines += ["| " + " | ".join(r[c] or "-" for c in cols) + " |" for r in rows]
    return "\n".join(lines)


def build(register, ncrs, events, week, day, verifier):
    cut = (int(week), DAYS.index(day))
    nrows, ex_ncrs, ex_events = ncr_tables(ncrs, events, cut)
    arows, ex_actions, withheld = action_table(register, ncrs, cut, verifier)
    counts = {s: sum(r["status"] == s for r in arows) for s in STATUSES}
    closed = [r["ncr_id"] for r in nrows if r["closed"] != "Not closed"]
    rep = [f"# Corrective-action tracker tables at Week {week}, {day} (end of day)", "",
           f"Authorised verifier used: {verifier or 'Not provided - confirmation required'}", "",
           "## Action status", "", md_table(arows, ["ca_id", "ncr_id", "due_week", "status", "weeks_overdue", "check_note"]), "",
           "## Counts", ""]
    rep += [f"- {s}: {counts[s]}" for s in STATUSES]
    rep += [f"- Actions: {len(arows)}", "", "## NCR status at the cut-off", "",
            md_table(nrows, ["ncr_id", "latest_event", "correction_verified", "closed"]), "",
            f"- NCRs raised by the cut-off: {len(nrows)}; closed: {len(closed)}; open: {len(nrows) - len(closed)}", "",
            "## Left out because dated after the cut-off", "",
            f"- NCRs raised after the cut-off: {len(ex_ncrs)} ({', '.join(ex_ncrs) or 'none'})",
            f"- NCR events after the cut-off: {len(ex_events)}",
            f"- Actions whose NCR was raised after the cut-off: {len(ex_actions)} ({', '.join(ex_actions) or 'none'})",
            f"- Fields withheld: {len(withheld)}"] + [f"  - {w}" for w in withheld]
    rep += ["", "Prepared by script (ch06_tracker_tables.py). Checked against the register by: ______ (role, date)", ""]
    return arows, nrows, "\n".join(rep)


def main():
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    for a in ("--register", "--ncrs", "--events", "--week", "--out-dir"):
        p.add_argument(a, required=True)
    p.add_argument("--day", required=True, choices=DAYS)
    p.add_argument("--verifier", default="")
    a = p.parse_args()
    arows, nrows, rep = build(read(a.register), read(a.ncrs), read(a.events), a.week, a.day, a.verifier)
    out = pathlib.Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    for name, rows in (("actions_status.csv", arows), ("ncr_status.csv", nrows)):
        with open(out / name, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else ["none"], lineterminator="\n")
            w.writeheader()
            w.writerows(rows)
    (out / "report.md").write_text(rep, encoding="utf-8")
    print(rep)


if __name__ == "__main__":
    main()
