#!/usr/bin/env python3
"""Chapter 8 companion tool: handover requirement status table, prepared before any AI drafting.

Python 3 standard library only. Deterministic: the same inputs always give the same output.

INPUTS (CSV files with the same columns as the chapter's fictional data):
  --schedule  handover schedule: hr_id, package, document_type, scope, accepted_by_role (other columns ignored)
  --index     handover index: hi_id, hr_id, document, document_type, received_week, received_day, status,
              status_by_role, status_record, linked_ncr, remarks
  --cutoff    the cut-off, as "WEEK DAY", for example "25 Monday"
  --extract   give this flag if the index is an extract, not the full index
  --events    optional NCR event log: ncr_id, week, day, event, by_role (as ncr_events.csv)
  --csv       optional path: write the status table as CSV (one row per requirement)
  --md        optional path: write the full Markdown report (default: print it)

WHAT IT DOES (rules, not judgement):
  - Ignores index entries received after the cut-off, and NCR events after the cut-off; lists them as excluded.
  - Ignores superseded entries; lists them.
  - Counts requirements, not entries. A requirement is counted only from an entry filed against it whose
    document type equals the required type. Its "Counted as" value is:
      the status as recorded, if Accepted or Reviewed - comments open was recorded by the role the schedule
        gives for acceptance, or the status is Received - not reviewed or Missing;
      "Confirmation required", if Accepted or Reviewed - comments open was recorded by another role, if two
        current entries of the required type are filed against it, or if a non-Missing entry has no
        received date;
      "Missing", if the full index has no current entry of the required type filed against it and no
        possible match qualifies for it;
      "Missing — possible match awaiting verification", if the full index has no such entry but a possible
        match qualifies (see below). It is still missing: the candidate is not counted against it;
      "Not in the supplied extract (may exist; confirm)", if the index is an extract and no such entry is in it
        (a qualifying possible match is then given in the check note only).
    Every requirement has exactly one "Counted as" value, so the category totals add up to the requirements.
  - Lists POSSIBLE MATCHES. A candidate for an entry whose type differs from its filed requirement is a
    requirement that (a) has the entry's document type, (b) has no current entry of its own, and (c) shares at
    least one significant word between the entry's title and the requirement's scope. Words are compared in
    lower case and in the singular (a plural "s", "es" or "ies" is undone); short words (under 3 letters), numbers, the words of the
    document type, and the general words listed in GENERAL are not significant. The matched words are printed
    as the basis. If exactly one requirement qualifies, it is suggested ("Possible match, to confirm"). If
    several qualify, all are listed and none is suggested. Type alone is never a basis. A possible match
    changes no recorded status, no filed entry and no other category's count; the candidate is never counted
    against any requirement.

OUTPUTS:
  - status table (CSV and Markdown): one row per requirement, with "Counted as" and a check note;
  - summary counts by "Counted as"; possible matches; superseded entries; excluded entries and events;
    linked NCR states at the cut-off (if --events is given).

WHAT A PERSON MUST STILL CHECK (the script cannot):
  - that the index itself is right: received dates, statuses and the roles that recorded them;
  - that each document is the right document for its requirement: content, scope, revision, signatures;
  - every possible match and every misfiled entry with no candidate, against the document itself, before the
    index is changed: matching words is not reading the document. Until the index is changed by the role that
    records it, the requirement keeps its "Counted as" value;
  - every "Confirmation required" row, with the role that recorded the status;
  - that the cut-off and the full-or-extract flag are right.
The table is "prepared by script"; it becomes an input to drafting only once a named role has checked it.
"""
import argparse
import csv
import re
import sys

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
ACC, REV, NR, MISS = "Accepted", "Reviewed — comments open", "Received — not reviewed", "Missing"
CONF, EXTRACT = "Confirmation required", "Not in the supplied extract (may exist; confirm)"
MPM = "Missing — possible match awaiting verification"
ORDER = [ACC, REV, NR, MISS, MPM, EXTRACT, CONF]
GENERAL = {"all", "and", "the", "for", "with", "from", "includes", "including", "listed", "rev", "pack", "set",
           "file", "copy", "register", "record", "certificate", "manual", "drawing", "document", "level",
           "system", "section", "photo"}
COLS = ["hr_id", "package", "document_type", "scope", "filed_entry", "entry_type", "received",
        "recorded_status", "recorded_by", "review_record", "linked_ncr", "counted_as", "check_note", "remarks"]


def when(week, day):
    return (int(week), DAYS.index(day))


def words(text, drop=""):
    """Significant words of a title or scope, in order of first appearance (see the docstring)."""
    def norm(w):  # plural to singular: deliveries -> delivery, finishes -> finish, boilers -> boiler
        if len(w) > 4 and w.endswith("ies"):
            return w[:-3] + "y"
        if len(w) > 4 and w.endswith(("shes", "ches", "xes", "sses")):
            return w[:-2]
        return w[:-1] if len(w) > 3 and w.endswith("s") and not w.endswith("ss") else w
    skip = {norm(w) for w in GENERAL} | {norm(w) for w in re.findall(r"[a-z]+", drop.lower())}
    out = []
    for w in map(norm, re.findall(r"[a-z]+", text.lower())):
        if len(w) >= 3 and w not in skip and w not in out:
            out.append(w)
    return out


def read(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def build(schedule, index, cutoff, extract=False, events=None):
    """Return a dict with the status table and the supporting lists. cutoff = (week, day index)."""
    excluded, superseded, current = [], [], []
    for e in index:
        if e["received_week"] and when(e["received_week"], e["received_day"]) > cutoff:
            excluded.append(e)
        elif e["status"] == "Superseded":
            superseded.append(e)
        else:
            current.append(e)
    req = {r["hr_id"]: r for r in schedule}
    own = {h: [e for e in current if e["hr_id"] == h and e["document_type"] == r["document_type"]] for h, r in req.items()}
    misfiled = [e for e in current if e["hr_id"] in req and e["document_type"] != req[e["hr_id"]]["document_type"]]
    matches, unmatched, cand_for = [], [], {}
    for e in misfiled:
        title = words(e["document"], e["document_type"])
        cands = []
        for h, r in req.items():
            if r["document_type"] == e["document_type"] and not own[h]:
                basis = [w for w in words(r["scope"], r["document_type"]) if w in title]
                if basis:
                    cands.append({"hr_id": h, "scope": r["scope"], "basis": basis})
        if not cands:
            unmatched.append(e)
            continue
        m = {"hi_id": e["hi_id"], "document": e["document"], "entry_type": e["document_type"],
             "filed_against": e["hr_id"], "candidates": cands, "suggested": cands[0]["hr_id"] if len(cands) == 1 else ""}
        matches.append(m)
        for c in cands:
            cand_for.setdefault(c["hr_id"], []).append((m, c))
    table = []
    for h, r in req.items():
        row = dict.fromkeys(COLS, "")
        row.update(hr_id=h, package=r["package"], document_type=r["document_type"], scope=r["scope"])
        filed = [e for e in current if e["hr_id"] == h]
        notes = []
        for e in filed:
            if e not in own[h]:
                notes.append(f"{e['hi_id']} filed against it is type {e['document_type']}, not counted")
        if len(own[h]) == 1:
            e = own[h][0]
            row.update(filed_entry=e["hi_id"], entry_type=e["document_type"],
                       received=f"Week {e['received_week']}, {e['received_day']}" if e["received_week"] else "",
                       recorded_status=e["status"], recorded_by=e["status_by_role"],
                       review_record=e["status_record"], linked_ncr=e["linked_ncr"], remarks=e["remarks"])
            if e["status"] in (ACC, REV) and e["status_by_role"] != r["accepted_by_role"]:
                row["counted_as"] = CONF
                notes.append(f"'{e['status']}' recorded by {e['status_by_role']}; the schedule gives "
                             f"acceptance to {r['accepted_by_role']}")
            elif e["status"] != MISS and not e["received_week"]:
                row["counted_as"] = CONF
                notes.append("no received date recorded")
            else:
                row["counted_as"] = e["status"]
                if e["status"] == MISS:
                    notes.append(f"recorded as Missing by {e['status_by_role']}")
        elif len(own[h]) > 1:
            row.update(filed_entry=", ".join(e["hi_id"] for e in own[h]), counted_as=CONF)
            notes.append("more than one current entry of the required type")
        else:
            if filed:
                e = filed[0]
                row.update(filed_entry=e["hi_id"], entry_type=e["document_type"],
                           received=f"Week {e['received_week']}, {e['received_day']}" if e["received_week"] else "",
                           recorded_status=e["status"], recorded_by=e["status_by_role"],
                           review_record=e["status_record"], linked_ncr=e["linked_ncr"], remarks=e["remarks"])
            row["counted_as"] = EXTRACT if extract else (MPM if h in cand_for else MISS)
            notes.append("no entry of the required type in the supplied extract" if extract else
                         "no entry of the required type filed against it in the full index")
        for m, c in cand_for.get(h, []):
            basis = ", ".join(c["basis"])
            if m["suggested"]:
                notes.append(f"possible match to confirm: {m['hi_id']} (matched words: {basis}; not counted)")
            else:
                notes.append(f"one of {len(m['candidates'])} candidates for {m['hi_id']} (matched words: {basis}); "
                             f"no single match suggested; not counted")
        row["check_note"] = "; ".join(notes)
        table.append(row)
    ncr_states, late_events = [], []
    if events is not None:
        linked = sorted({e["linked_ncr"] for e in current + superseded if e["linked_ncr"]})
        for n in linked:
            evs = [v for v in events if v["ncr_id"] == n]
            done = [v for v in evs if when(v["week"], v["day"]) <= cutoff]
            late_events += [v for v in evs if when(v["week"], v["day"]) > cutoff]
            names = [v["event"] for v in done]
            last = done[-1] if done else None
            ncr_states.append({"ncr_id": n,
                               "state": f"{last['event']} (Week {last['week']}, {last['day']}, {last['by_role']})" if last else "No event recorded",
                               "correction_verified": "yes" if "Correction verified" in names else "no",
                               "closed": "yes" if "Closed" in names else "no"})
    counts = {k: sum(1 for t in table if t["counted_as"] == k) for k in ORDER}
    assert sum(counts.values()) == len(table), "every requirement has exactly one Counted as value"
    return {"table": table, "counts": counts, "matches": matches, "unmatched": unmatched, "superseded": superseded,
            "excluded": excluded, "late_events": late_events, "ncr_states": ncr_states}


def markdown(res, cutoff_text, extract=False, checked_by="[role], [date]"):
    esc = lambda s: str(s).replace("|", "/") or "(blank)"
    out = [f"REQUIREMENT STATUS TABLE - prepared by script ch08_dossier_status.py, checked by {checked_by}",
           f"Cut-off: {cutoff_text}. Index supplied: {'EXTRACT' if extract else 'full index at the cut-off'}.",
           f"Requirements: {len(res['table'])}. " + ". ".join(f"{k}: {v}" for k, v in res["counts"].items() if v) + ".",
           "", "| " + " | ".join(COLS) + " |", "|" + "---|" * len(COLS)]
    out += ["| " + " | ".join(esc(r[c]) for c in COLS) + " |" for r in res["table"]]
    out += ["", "POSSIBLE MATCHES (a candidate has the entry's document type, no entry of its own, and at least one "
            "significant title word in its scope; type alone is not a basis. To confirm against the document; a "
            "candidate is never counted against a requirement until the index is changed)"]
    for m in res["matches"]:
        head = f"- {m['hi_id']} ('{m['document']}', type {m['entry_type']}), filed against {m['filed_against']}. "
        cs = [f"{c['hr_id']} (scope: '{c['scope']}'; matched words: {', '.join(c['basis'])})" for c in m["candidates"]]
        if m["suggested"]:
            out.append(head + f"Possible match, to confirm: {cs[0]}.")
        else:
            out.append(head + f"{len(cs)} candidates, no single match is suggested: " + "; ".join(cs) + ".")
    out += [f"- {e['hi_id']} ('{e['document']}', type {e['document_type']}), filed against {e['hr_id']}. "
            f"No possible match: no requirement of this type without an entry shares a significant word."
            for e in res["unmatched"]]
    if not res["matches"] and not res["unmatched"]:
        out.append("- none")
    out += ["", "SUPERSEDED ENTRIES (not counted)"]
    out += [f"- {e['hi_id']} ({e['document']}), filed against {e['hr_id']}: {e['remarks'] or 'superseded'}"
            for e in res["superseded"]] or ["- none"]
    out += ["", "EXCLUDED: dated after the cut-off (not used)"]
    ex = [f"- index entry {e['hi_id']} ({e['document']}), received Week {e['received_week']}, {e['received_day']}, "
          f"status '{e['status']}'" for e in res["excluded"]]
    ex += [f"- {v['ncr_id']} event '{v['event']}', Week {v['week']}, {v['day']}" for v in res["late_events"]]
    out += ex or ["- none"]
    out += [f"Excluded: {len(res['excluded'])} index entries, {len(res['late_events'])} NCR events."]
    if res["ncr_states"]:
        out += ["", "LINKED NCR STATES AT THE CUT-OFF (last event recorded on or before the cut-off)",
                "| NCR | state at the cut-off | correction verified recorded | closed recorded |", "|---|---|---|---|"]
        out += [f"| {s['ncr_id']} | {s['state']} | {s['correction_verified']} | {s['closed']} |" for s in res["ncr_states"]]
    return "\n".join(out) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--schedule", required=True); ap.add_argument("--index", required=True)
    ap.add_argument("--cutoff", required=True, help='"WEEK DAY", e.g. "25 Monday"')
    ap.add_argument("--extract", action="store_true"); ap.add_argument("--events")
    ap.add_argument("--csv"); ap.add_argument("--md"); ap.add_argument("--checked-by", default="[role], [date]")
    a = ap.parse_args(argv)
    wk, day = a.cutoff.split()
    res = build(read(a.schedule), read(a.index), when(wk, day), a.extract, read(a.events) if a.events else None)
    if a.csv:
        with open(a.csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=COLS, lineterminator="\n"); w.writeheader(); w.writerows(res["table"])
    text = markdown(res, f"Week {wk}, {day}", a.extract, a.checked_by)
    if a.md:
        open(a.md, "w", encoding="utf-8").write(text)
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
