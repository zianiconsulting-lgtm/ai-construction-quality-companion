#!/usr/bin/env python3
"""Chapter 9 companion tool: filter the NCR records to a cut-off before drafting lessons.

Python 3, standard library only. Deterministic: the same files and arguments always give the same output.

INPUTS (CSV files with the same columns as the book's files; other columns are kept as they are)
  --ncrs     NCR log: ncr_id, raised_week, raised_day, ...
  --events   NCR events: ncr_id, week, day, event, detail, by_role, record_id
  --actions  corrective-action tracker (optional): ca_id, ncr_id, ..., reported_complete_week,
             verified_effective, verified_by_role, verification_record
  --week, --day   the cut-off: records to the end of that day (day: Monday to Friday)
  --out-dir  folder for the outputs (created if needed)

OUTPUTS
  ncrs_at_cutoff.csv, ncr_events_at_cutoff.csv, corrective_actions_at_cutoff.csv
             the records kept: NCRs raised on or before the cut-off, events on or before it, and actions
             whose NCR is kept. An action's reported-complete week after the cut-off week is blanked, and so
             is its verification; a verification record dated "Week N [day]" after the cut-off is blanked.
  filter_summary.csv   item, count, detail: what was kept, what was excluded or withheld, the NCRs with a
             "Closed" event at the cut-off (the only possible lesson sources), the NCRs open, the
             "Cause recorded" events, and the verification records that carry no date
  filter_report.md     the same summary in Markdown, with a line for the checker's name and date

WHAT A PERSON MUST STILL CHECK (the tool does not do this)
  - that the input files are complete and current, and that the cut-off is the one intended;
  - every verification record with no date: was it recorded by the cut-off?
  - a reported-complete week equal to the cut-off week (the day is not recorded);
  - the counts, by hand, against the event log.
  The tool decides nothing: it does not close, verify or explain any NCR, and it does not judge
  whether an NCR is a good source of a lesson. "Closed" here means only that a "Closed" event is recorded.

Example (from the book folder):
  python3 05_Companion/public/tools/ch09_cutoff_filter.py --ncrs 03_Datasets/ncrs.csv \
    --events 03_Datasets/ncr_events.csv --actions 03_Datasets/corrective_actions.csv \
    --week 26 --day Monday --out-dir out_ch09
"""
import argparse
import csv
import pathlib
import re

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]


def read(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def when(week, day):
    return (int(week), DAYS.index(day))


def record_date(text):
    m = re.search(r"Week (\d+)(?:,? (Monday|Tuesday|Wednesday|Thursday|Friday))?", text or "")
    return (int(m.group(1)), DAYS.index(m.group(2)) if m.group(2) else None) if m else None


def id_list(ids):
    """'NCR-001 to NCR-014' for a consecutive run of one prefix, else a comma list; 'none' if empty."""
    if not ids:
        return "none"
    nums = [re.match(r"(.*?)(\d+)$", i) for i in ids]
    if all(nums) and len({m.group(1) for m in nums}) == 1 and len(ids) > 2:
        n = [int(m.group(2)) for m in nums]
        if n == list(range(n[0], n[0] + len(n))):
            return f"{ids[0]} to {ids[-1]}"
    return ", ".join(ids)


def filter_records(ncrs, events, actions, week, day):
    cut = (int(week), DAYS.index(day))
    k_ncrs = [n for n in ncrs if when(n["raised_week"], n["raised_day"]) <= cut]
    kept_ids = {n["ncr_id"] for n in k_ncrs}
    x_ncrs = [n["ncr_id"] for n in ncrs if n["ncr_id"] not in kept_ids]
    k_ev = [e for e in events if when(e["week"], e["day"]) <= cut]
    x_ev = len(events) - len(k_ev)
    k_ca, x_ca, withheld, undated = [], [], [], []
    for a in actions or []:
        if a["ncr_id"] not in kept_ids:
            x_ca.append(a["ca_id"])
            continue
        a = dict(a)
        rep = a.get("reported_complete_week", "")
        if rep and int(rep) > cut[0]:
            withheld.append(f"{a['ca_id']} (reported complete Week {rep})")
            a.update(reported_complete_week="", verified_effective="", verified_by_role="", verification_record="")
        d = record_date(a.get("verification_record", ""))
        if a.get("verification_record") and d and (d[0] > cut[0] or (d[1] is not None and (d[0], d[1]) > cut)):
            withheld.append(f"{a['ca_id']} (verification dated after the cut-off)")
            a.update(verified_effective="Not yet verified" if a["reported_complete_week"] else "", verified_by_role="", verification_record="")
        elif a.get("verification_record") and not d:
            undated.append(a["ca_id"])
        k_ca.append(a)
    closed = sorted({e["ncr_id"] for e in k_ev if e["event"] == "Closed"})
    open_ = [n["ncr_id"] for n in k_ncrs if n["ncr_id"] not in closed]
    causes = [f"{e['ncr_id']} ({e['record_id'] or 'no record ID'})" for e in k_ev if e["event"] == "Cause recorded"]
    summary = [
        ("NCRs kept (raised on or before the cut-off)", len(k_ncrs), id_list([n["ncr_id"] for n in k_ncrs])),
        ("NCRs excluded (raised after the cut-off)", len(x_ncrs), id_list(x_ncrs)),
        ("NCR events kept", len(k_ev), ""),
        ("NCR events excluded (after the cut-off)", x_ev, ""),
        ("Corrective actions kept", len(k_ca), id_list([a["ca_id"] for a in k_ca])),
        ("Corrective actions excluded (NCR raised after the cut-off)", len(x_ca), id_list(x_ca)),
        ("Corrective-action entries withheld (dated after the cut-off)", len(withheld), ", ".join(withheld) or "none"),
        ("NCRs with a Closed event at the cut-off (possible sources)", len(closed), id_list(closed)),
        ("NCRs open at the cut-off (not sources)", len(open_), id_list(open_)),
        ("Cause recorded events at the cut-off", len(causes), ", ".join(causes) or "none"),
        ("Verification records with no date (confirm)", len(undated), id_list(undated)),
    ]
    summary = [{"item": i, "count": str(c), "detail": d} for i, c, d in summary]
    return k_ncrs, k_ev, k_ca, summary


def main():
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    for a in ("--ncrs", "--events", "--week", "--out-dir"):
        p.add_argument(a, required=True)
    p.add_argument("--actions", default="")
    p.add_argument("--day", required=True, choices=DAYS)
    a = p.parse_args()
    ncrs, events = read(a.ncrs), read(a.events)
    actions = read(a.actions) if a.actions else []
    k_ncrs, k_ev, k_ca, summary = filter_records(ncrs, events, actions, a.week, a.day)
    out = pathlib.Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    for name, rows, cols in (("ncrs_at_cutoff.csv", k_ncrs, list(ncrs[0]) if ncrs else []),
                             ("ncr_events_at_cutoff.csv", k_ev, list(events[0]) if events else []),
                             ("corrective_actions_at_cutoff.csv", k_ca, list(actions[0]) if actions else []),
                             ("filter_summary.csv", summary, ["item", "count", "detail"])):
        if not cols:
            continue
        with open(out / name, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
            w.writeheader()
            w.writerows(rows)
    rep = [f"# Records filtered to Week {a.week}, {a.day} (end of day)", "", "| Item | Count | Detail |", "|---|---|---|"]
    rep += [f"| {s['item']} | {s['count']} | {s['detail'] or '-'} |" for s in summary]
    rep += ["", "Prepared by script (ch09_cutoff_filter.py). Checked by: ______ (role, date)", ""]
    (out / "filter_report.md").write_text("\n".join(rep), encoding="utf-8")
    print("\n".join(rep))


if __name__ == "__main__":
    main()
